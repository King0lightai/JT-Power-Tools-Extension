/* global React */
// Portal dashboard — toolbox feel, plain-english, AI setup via stepper not code

function PortalDashboard() {
  const [section, setSection] = React.useState('ai');
  return (
    <div className="jt-frame" style={{ width: 1280, height: 900, background: 'var(--ink-050)', display: 'flex', flexDirection: 'column' }}>
      <div className="jt-tape" style={{ height: 6 }}/>

      {/* Top nav */}
      <div style={{ display: 'flex', alignItems: 'center', padding: '16px 32px', borderBottom: '1px solid var(--rule)', background: 'var(--ink-100)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, background: 'var(--flame)', display: 'grid', placeItems: 'center', borderRadius: 4 }}>
            <span className="jt-display" style={{ fontSize: 17, color: '#0B0B0B' }}>JT</span>
          </div>
          <span className="jt-display" style={{ fontSize: 18, letterSpacing: '0.05em', color: 'var(--ink-900)' }}>POWER TOOLS</span>
          <span style={{ marginLeft: 12, paddingLeft: 12, borderLeft: '1px solid var(--rule)', fontSize: 13, color: 'var(--ink-600)', fontWeight: 500 }}>Portal</span>
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{ fontSize: 13, color: 'var(--ink-700)', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span className="jt-dot"/>Titus Contracting
          </span>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--flame)', color: '#0B0B0B', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-display)', fontSize: 15 }}>R</div>
        </div>
      </div>

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Sidebar */}
        <aside style={{ width: 260, borderRight: '1px solid var(--rule)', padding: '28px 0', background: 'var(--ink-050)' }}>
          {[
            { id: 'home', icon: 'ph-house', label: 'Home' },
            { id: 'ai', icon: 'ph-robot', label: 'AI helper', badge: 'Setup' },
            { id: 'team', icon: 'ph-users-three', label: 'Your team' },
            { id: 'extension', icon: 'ph-puzzle-piece', label: 'The extension' },
            { id: 'account', icon: 'ph-id-badge', label: 'Account & billing' },
          ].map(s => {
            const active = section === s.id;
            return (
              <button key={s.id} onClick={() => setSection(s.id)} style={{
                display: 'flex', alignItems: 'center', gap: 12, width: '100%',
                padding: '12px 28px', background: active ? 'var(--ink-100)' : 'transparent',
                border: 'none',
                borderLeft: `3px solid ${active ? 'var(--flame)' : 'transparent'}`,
                color: active ? 'var(--ink-900)' : 'var(--ink-600)',
                cursor: 'pointer', fontFamily: 'var(--font-ui)', fontSize: 14, fontWeight: active ? 600 : 500,
              }}>
                <i className={`ph ${s.icon}`} style={{ fontSize: 17, color: active ? 'var(--flame)' : 'var(--ink-500)' }}/>
                <span style={{ flex: 1, textAlign: 'left' }}>{s.label}</span>
                {s.badge && <span style={{ fontSize: 10, padding: '2px 6px', background: 'var(--flame-soft)', color: 'var(--flame)', borderRadius: 10, fontWeight: 700 }}>{s.badge}</span>}
              </button>
            );
          })}

          <div style={{ margin: '28px 28px', padding: 16, border: '1px solid var(--rule)', background: 'var(--ink-100)', borderRadius: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <i className="ph ph-crown" style={{ color: 'var(--flame)', fontSize: 18 }}/>
              <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink-900)' }}>Power User</span>
            </div>
            <div style={{ fontSize: 12, color: 'var(--ink-600)', marginBottom: 12 }}>All 23 tools + AI. Renews Dec 14.</div>
            <div style={{ height: 6, background: 'var(--ink-200)', borderRadius: 3, marginBottom: 6, overflow: 'hidden' }}>
              <div style={{ width: '53%', height: '100%', background: 'var(--flame)' }}/>
            </div>
            <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>8 of 15 seats used</div>
          </div>
        </aside>

        {/* Main */}
        <main style={{ flex: 1, overflow: 'auto', padding: '40px 48px' }}>
          {section === 'ai' ? <AiSection/> : <HomeSection/>}
        </main>
      </div>
    </div>
  );
}

function HomeSection() {
  return (
    <div>
      <div className="jt-eyebrow" style={{ marginBottom: 8 }}>Welcome back</div>
      <h1 className="jt-display" style={{ fontSize: 64, color: 'var(--ink-900)', marginBottom: 32 }}>HEY RYAN.</h1>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 20 }}>
        {[
          ['ph-wrench', '8 tools', 'running now', 'var(--green)'],
          ['ph-users-three', '8 of 15', 'seats used'],
          ['ph-robot', 'Connected', 'Claude + ChatGPT', 'var(--flame)'],
        ].map(([i, big, sub, color]) => (
          <div key={big} className="jt-card" style={{ padding: 24 }}>
            <i className={`ph ${i}`} style={{ fontSize: 26, color: color || 'var(--ink-600)', marginBottom: 14 }}/>
            <div className="jt-display" style={{ fontSize: 40, color: 'var(--ink-900)' }}>{big}</div>
            <div style={{ fontSize: 13, color: 'var(--ink-600)', marginTop: 4 }}>{sub}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AiSection() {
  return (
    <div>
      <div className="jt-eyebrow" style={{ marginBottom: 8 }}>AI helper</div>
      <h1 className="jt-display" style={{ fontSize: 64, color: 'var(--ink-900)', marginBottom: 8 }}>
        HAVE CLAUDE READ <span style={{ color: 'var(--flame)' }}>YOUR JOBS.</span>
      </h1>
      <p style={{ fontSize: 16, color: 'var(--ink-600)', marginBottom: 36, maxWidth: 640, lineHeight: 1.6 }}>
        Three clicks to let Claude, ChatGPT, or Cursor answer questions about your schedule, budgets, and customers. No coding.
      </p>

      {/* 3-step cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, marginBottom: 40 }}>
        {[
          ['1', 'ph-key', 'Pick your org', 'Which JobTread company should Claude read?', 'Titus Contracting', 'Ready'],
          ['2', 'ph-link-simple', 'Pick your AI', 'Claude, ChatGPT, Cursor, or Claude Desktop.', 'Claude.ai', 'Ready'],
          ['3', 'ph-check-circle', 'Click connect', 'We handle the handshake — no config files.', 'Connect →', 'Do this'],
        ].map(([n, icon, title, desc, cta, state]) => {
          const active = state === 'Do this';
          return (
            <div key={n} className="jt-card" style={{ padding: 24, position: 'relative', borderColor: active ? 'var(--flame)' : undefined }}>
              <div style={{
                position: 'absolute', top: -14, left: 20,
                width: 32, height: 32, background: active ? 'var(--flame)' : 'var(--ink-200)', color: active ? '#0B0B0B' : 'var(--ink-700)',
                borderRadius: '50%', display: 'grid', placeItems: 'center',
                fontFamily: 'var(--font-display)', fontSize: 18,
                border: '2px solid var(--ink-050)',
              }}>{n}</div>
              <i className={`ph ${icon}`} style={{ fontSize: 26, color: active ? 'var(--flame)' : 'var(--ink-500)', marginBottom: 14, marginTop: 8 }}/>
              <h3 style={{ fontSize: 18, fontWeight: 700, color: 'var(--ink-900)', marginBottom: 6 }}>{title}</h3>
              <p style={{ fontSize: 13, color: 'var(--ink-600)', lineHeight: 1.55, marginBottom: 18 }}>{desc}</p>
              <button style={{
                padding: '10px 14px', background: active ? 'var(--flame)' : 'var(--ink-200)',
                color: active ? '#0B0B0B' : 'var(--ink-800)',
                border: 'none', borderRadius: 5, fontSize: 13, fontWeight: 600, cursor: 'pointer',
              }}>{cta}</button>
            </div>
          );
        })}
      </div>

      {/* Connected AIs */}
      <div className="jt-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--rule)', display: 'flex', alignItems: 'center' }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, color: 'var(--ink-900)' }}>Connected AIs</h3>
          <span style={{ marginLeft: 10, fontSize: 12, color: 'var(--ink-500)' }}>2 active</span>
          <button style={{ marginLeft: 'auto', padding: '8px 14px', background: 'var(--flame)', color: '#0B0B0B', border: 'none', borderRadius: 5, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>+ Connect another</button>
        </div>
        {[
          ['Claude.ai', 'Web + mobile', 'ph-chat-teardrop-text', true, '2 hours ago'],
          ['ChatGPT', 'Custom GPT', 'ph-sparkle', true, 'Yesterday'],
          ['Cursor', 'IDE', 'ph-code', false, 'Never'],
        ].map(([name, sub, icon, connected, last], i) => (
          <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px 24px', borderTop: i === 0 ? 'none' : '1px solid var(--rule-soft)' }}>
            <div style={{ width: 40, height: 40, background: 'var(--ink-200)', border: '1px solid var(--rule)', borderRadius: 8, display: 'grid', placeItems: 'center', color: connected ? 'var(--flame)' : 'var(--ink-500)' }}>
              <i className={`ph ${icon}`} style={{ fontSize: 18 }}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink-900)' }}>{name}</div>
              <div style={{ fontSize: 12, color: 'var(--ink-600)' }}>{sub} · Last used {last}</div>
            </div>
            <span style={{
              fontSize: 11, padding: '4px 10px', borderRadius: 10, fontWeight: 700, letterSpacing: '0.04em', textTransform: 'uppercase',
              background: connected ? 'oklch(25% 0.12 150 / 0.4)' : 'var(--ink-200)',
              color: connected ? 'var(--green)' : 'var(--ink-500)',
            }}>
              {connected ? 'Connected' : 'Off'}
            </span>
            <button style={{ padding: '6px 12px', background: 'transparent', border: '1px solid var(--rule)', color: 'var(--ink-700)', fontSize: 12, fontWeight: 600, borderRadius: 5, cursor: 'pointer' }}>
              {connected ? 'Manage' : 'Set up'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

window.PortalDashboard = PortalDashboard;
