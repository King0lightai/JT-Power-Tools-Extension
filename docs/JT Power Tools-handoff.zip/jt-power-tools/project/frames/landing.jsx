/* global React */
// Landing — feels like a contractor's toolbox catalog, not a dev site

function LandingFrame() {
  return (
    <div className="jt-frame" style={{ width: 1280, height: 3600, background: 'var(--ink-050)', overflow: 'hidden' }}>
      <div className="jt-tape" style={{ height: 8 }}/>

      {/* Nav */}
      <nav style={{ position: 'sticky', top: 0, display: 'flex', alignItems: 'center', padding: '18px 48px', borderBottom: '1px solid var(--rule)', background: 'oklch(16% 0.006 50 / 0.92)', backdropFilter: 'blur(10px)', zIndex: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, background: 'var(--flame)', display: 'grid', placeItems: 'center', borderRadius: 4 }}>
            <span className="jt-display" style={{ fontSize: 17, color: '#0B0B0B' }}>JT</span>
          </div>
          <span className="jt-display" style={{ fontSize: 18, letterSpacing: '0.05em', color: 'var(--ink-900)' }}>POWER TOOLS</span>
        </div>
        <div style={{ display: 'flex', gap: 28, marginLeft: 64 }}>
          {['The tools', 'Pricing', 'Roadmap', 'About', 'Docs'].map(l => (
            <a key={l} style={{ fontSize: 14, color: 'var(--ink-700)', cursor: 'pointer', fontWeight: 500 }}>{l}</a>
          ))}
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 10 }}>
          <button style={{ padding: '10px 16px', background: 'transparent', border: '1px solid var(--rule)', color: 'var(--ink-800)', fontSize: 13, cursor: 'pointer', fontWeight: 600, borderRadius: 5 }}>Sign in</button>
          <button style={{ padding: '10px 18px', background: 'var(--flame)', border: 'none', color: '#0B0B0B', fontSize: 13, cursor: 'pointer', fontWeight: 700, borderRadius: 5, boxShadow: '0 2px 0 rgba(0,0,0,0.3)' }}>Install free</button>
        </div>
      </nav>

      {/* HERO */}
      <section style={{ padding: '90px 48px 40px', borderBottom: '1px solid var(--rule)', position: 'relative' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 0.9fr', gap: 56, alignItems: 'end' }}>
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px', background: 'var(--flame-soft)', border: '1px solid var(--flame)', borderRadius: 20, marginBottom: 28 }}>
              <i className="ph ph-hammer" style={{ color: 'var(--flame)', fontSize: 14 }}/>
              <span style={{ fontSize: 12, color: 'var(--flame)', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Built by a contractor</span>
            </div>
            <h1 className="jt-display" style={{ fontSize: 168, color: 'var(--ink-900)', lineHeight: 0.86, marginBottom: 28 }}>
              23 HACKS<br/>
              THAT MAKE<br/>
              JOBTREAD<br/>
              <span className="jt-serif" style={{ fontSize: 180, fontStyle: 'italic', color: 'var(--flame)' }}>awesome.</span>
            </h1>
          </div>
          <div style={{ paddingBottom: 32 }}>
            <p style={{ fontSize: 20, color: 'var(--ink-700)', lineHeight: 1.55, marginBottom: 28, maxWidth: 400 }}>
              Task checkboxes, rich text, dark mode, an AI helper, and all the other little things you've wished JobTread had. One Chrome extension.
            </p>
            <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
              <button style={{ padding: '16px 24px', background: 'var(--flame)', color: '#0B0B0B', border: 'none', borderRadius: 6, fontSize: 14, fontWeight: 700, cursor: 'pointer', boxShadow: '0 3px 0 rgba(0,0,0,0.3)' }}>
                <i className="ph ph-download-simple" style={{ marginRight: 8 }}/>Install free
              </button>
              <button style={{ padding: '16px 24px', background: 'transparent', color: 'var(--ink-800)', border: '1px solid var(--rule)', borderRadius: 6, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
                Watch demo
              </button>
            </div>
            <div style={{ display: 'flex', gap: 18, flexWrap: 'wrap' }}>
              <span style={{ fontSize: 12, color: 'var(--ink-600)' }}><span className="jt-dot" style={{ marginRight: 6 }}/>Free forever plan</span>
              <span style={{ fontSize: 12, color: 'var(--ink-600)' }}><span className="jt-dot" style={{ marginRight: 6 }}/>No credit card</span>
              <span style={{ fontSize: 12, color: 'var(--ink-600)' }}><span className="jt-dot" style={{ marginRight: 6 }}/>2,400+ users</span>
            </div>
          </div>
        </div>

        {/* Screenshot */}
        <div style={{ marginTop: 64, border: '1px solid var(--rule)', background: 'var(--ink-100)', padding: 12, borderRadius: 8 }}>
          <div style={{ display: 'flex', gap: 6, padding: '8px 4px 12px', alignItems: 'center' }}>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#FF5F57' }}/>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#FDBC2C' }}/>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#28C940' }}/>
            <span style={{ marginLeft: 12, fontSize: 12, color: 'var(--ink-500)' }}>app.jobtread.com/schedule — with Power Tools on</span>
          </div>
          <div style={{ aspectRatio: '16/9', background: 'var(--ink-000)', borderRadius: 4, display: 'grid', placeItems: 'center', textAlign: 'center' }}>
            <div>
              <i className="ph ph-image" style={{ fontSize: 44, color: 'var(--ink-500)', marginBottom: 12 }}/>
              <div style={{ fontSize: 14, color: 'var(--ink-600)' }}>Screenshot of JobTread schedule with checkboxes enabled</div>
              <div style={{ fontSize: 12, color: 'var(--ink-500)', marginTop: 4 }}>(Placeholder — plug in real product shot)</div>
            </div>
          </div>
        </div>
      </section>

      {/* TOOLBOX — feature cards as product-catalog tiles */}
      <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--rule)' }}>
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <div className="jt-eyebrow" style={{ marginBottom: 12 }}>The Toolbox</div>
          <h2 className="jt-display" style={{ fontSize: 84, color: 'var(--ink-900)' }}>EVERY HACK <span style={{ color: 'var(--flame)' }}>YOU'VE WANTED.</span></h2>
          <p style={{ fontSize: 17, color: 'var(--ink-600)', maxWidth: 600, margin: '18px auto 0' }}>Each one fixes something you've cursed out loud.</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
          {[
            ['ph-check-square', 'Task checkboxes', 'Check off schedule cards without opening them. Save 3 clicks per task.', 'Most loved'],
            ['ph-text-aa', 'Rich text everywhere', 'Bold, italic, lists, colors in every description box.'],
            ['ph-moon', 'Real dark mode', 'Actually readable. Not an afterthought tint.'],
            ['ph-robot', 'AI helper', 'Ask Claude about your jobs. Get answers from your data.', 'New'],
            ['ph-note-pencil', 'Quick notes', 'Persistent notepad on any page. Q+N opens it.'],
            ['ph-clipboard-text', 'Message templates', 'Save signatures and common replies. Paste in one click.'],
            ['ph-calculator', 'Auto-sum totals', 'Highlight rows — see cost, price, profit live.'],
            ['ph-file-pdf', 'PDF markup tools', 'Stamps, eraser, and annotations on PDFs.'],
            ['ph-columns', 'Frozen tabs', 'Keep job tabs visible while scrolling long pages.'],
          ].map(([i, t, d, tag], idx) => (
            <div key={t} style={{
              background: 'var(--ink-100)', border: '1px solid var(--rule)', borderRadius: 10,
              padding: 28, position: 'relative', overflow: 'hidden',
            }}>
              {tag && (
                <div style={{
                  position: 'absolute', top: 14, right: 14,
                  fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase',
                  padding: '4px 8px', borderRadius: 10,
                  background: 'var(--flame)', color: '#0B0B0B',
                }}>{tag}</div>
              )}
              <div style={{
                width: 56, height: 56, borderRadius: 10, background: 'var(--ink-200)',
                border: '1px solid var(--rule)',
                display: 'grid', placeItems: 'center', color: 'var(--flame)', marginBottom: 18,
              }}>
                <i className={`ph ${i}`} style={{ fontSize: 28 }}/>
              </div>
              <h3 style={{ fontSize: 20, fontWeight: 700, color: 'var(--ink-900)', marginBottom: 6, letterSpacing: '-0.01em' }}>{t}</h3>
              <p style={{ fontSize: 14, color: 'var(--ink-600)', lineHeight: 1.55 }}>{d}</p>
            </div>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: 40 }}>
          <button style={{ padding: '14px 24px', background: 'transparent', color: 'var(--ink-900)', border: '1px solid var(--rule)', borderRadius: 6, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
            See all 23 tools →
          </button>
        </div>
      </section>

      {/* TESTIMONIAL */}
      <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--rule)' }}>
        <div style={{ maxWidth: 960, margin: '0 auto', textAlign: 'center' }}>
          <i className="ph ph-quotes" style={{ fontSize: 40, color: 'var(--flame)', marginBottom: 20 }}/>
          <p className="jt-serif" style={{ fontSize: 52, color: 'var(--ink-900)', lineHeight: 1.15, fontStyle: 'italic' }}>
            "I get three hours back a week. The task checkboxes alone paid for the whole year."
          </p>
          <div style={{ marginTop: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14 }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'var(--ink-200)', border: '1px solid var(--rule)' }}/>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--ink-900)' }}>David B.</div>
              <div style={{ fontSize: 13, color: 'var(--ink-600)' }}>Operations Lead · Tulsa, OK</div>
            </div>
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--rule)' }}>
        <div style={{ textAlign: 'center', marginBottom: 48 }}>
          <div className="jt-eyebrow" style={{ marginBottom: 12 }}>Pricing</div>
          <h2 className="jt-display" style={{ fontSize: 84, color: 'var(--ink-900)' }}>THREE TIERS. <span style={{ color: 'var(--flame)' }}>NO CATCH.</span></h2>
          <p style={{ fontSize: 17, color: 'var(--ink-600)', maxWidth: 600, margin: '18px auto 0' }}>Start free. Upgrade when a tool pays for itself.</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, maxWidth: 1100, margin: '0 auto' }}>
          {[
            { name: 'Essential', price: '$0', per: 'forever', desc: 'The basics. No account needed.', feats: ['Dark mode', 'Rich text', 'Auto-sum totals', 'Schedule basics'], cta: 'Install free', featured: false },
            { name: 'Pro', price: '$9', per: 'per month', desc: 'For working contractors.', feats: ['Everything in Essential', 'Task checkboxes', 'Quick notes', 'Message templates', 'Custom theme colors', 'Availability filter'], cta: 'Start Pro', featured: true, tag: 'Most popular' },
            { name: 'Power User', price: '$24', per: 'per month', desc: 'For teams running the show.', feats: ['Everything in Pro', 'AI helper (Claude, GPT)', 'Team management', 'Budget changelog', 'Priority support'], cta: 'Go Power', featured: false },
          ].map((p, i) => (
            <div key={p.name} style={{
              background: p.featured ? 'var(--ink-100)' : 'var(--ink-050)',
              border: `${p.featured ? 2 : 1}px solid ${p.featured ? 'var(--flame)' : 'var(--rule)'}`,
              borderRadius: 12, padding: '32px 28px', position: 'relative',
            }}>
              {p.tag && <div style={{ position: 'absolute', top: -12, left: 24, padding: '4px 10px', background: 'var(--flame)', color: '#0B0B0B', fontSize: 11, fontWeight: 700, borderRadius: 10, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{p.tag}</div>}
              <h3 className="jt-display" style={{ fontSize: 32, color: 'var(--ink-900)', marginBottom: 6 }}>{p.name.toUpperCase()}</h3>
              <p style={{ fontSize: 13, color: 'var(--ink-600)', marginBottom: 20 }}>{p.desc}</p>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 24 }}>
                <span className="jt-display" style={{ fontSize: 68, color: 'var(--ink-900)' }}>{p.price}</span>
                <span style={{ fontSize: 13, color: 'var(--ink-500)' }}>{p.per}</span>
              </div>
              <button style={{
                width: '100%', padding: '14px', marginBottom: 24,
                background: p.featured ? 'var(--flame)' : 'transparent',
                color: p.featured ? '#0B0B0B' : 'var(--ink-900)',
                border: p.featured ? 'none' : '1px solid var(--rule)',
                borderRadius: 6, fontSize: 14, fontWeight: 700, cursor: 'pointer',
                boxShadow: p.featured ? '0 2px 0 rgba(0,0,0,0.3)' : 'none',
              }}>{p.cta}</button>
              <div style={{ borderTop: '1px solid var(--rule-soft)', paddingTop: 16 }}>
                {p.feats.map(f => (
                  <div key={f} style={{ display: 'flex', gap: 10, padding: '6px 0', fontSize: 14, color: 'var(--ink-700)' }}>
                    <i className="ph ph-check" style={{ color: p.featured ? 'var(--flame)' : 'var(--green)', fontSize: 16, marginTop: 2 }}/>
                    {f}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA strip */}
      <section style={{ padding: '80px 48px', background: 'var(--ink-100)', borderBottom: '1px solid var(--rule)' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', textAlign: 'center' }}>
          <h2 className="jt-display" style={{ fontSize: 72, color: 'var(--ink-900)', marginBottom: 16 }}>
            STOP FIGHTING JOBTREAD.<br/><span style={{ color: 'var(--flame)' }}>START USING IT.</span>
          </h2>
          <p style={{ fontSize: 17, color: 'var(--ink-600)', marginBottom: 28 }}>Install takes 30 seconds. No sign-up required.</p>
          <button style={{ padding: '18px 32px', background: 'var(--flame)', color: '#0B0B0B', border: 'none', borderRadius: 6, fontSize: 16, fontWeight: 700, cursor: 'pointer', boxShadow: '0 3px 0 rgba(0,0,0,0.3)' }}>
            <i className="ph ph-download-simple" style={{ marginRight: 10 }}/>Add to Chrome — free
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ padding: '56px 48px 32px', background: 'var(--ink-050)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 48 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              <div style={{ width: 28, height: 28, background: 'var(--flame)', display: 'grid', placeItems: 'center', borderRadius: 4 }}>
                <span className="jt-display" style={{ fontSize: 15, color: '#0B0B0B' }}>JT</span>
              </div>
              <span className="jt-display" style={{ fontSize: 18, letterSpacing: '0.05em', color: 'var(--ink-900)' }}>POWER TOOLS</span>
            </div>
            <p style={{ fontSize: 14, color: 'var(--ink-600)', maxWidth: 340, lineHeight: 1.6 }}>
              Built by contractors, for contractors. Not affiliated with JobTread Software.
            </p>
          </div>
          {[
            ['PRODUCT', ['The tools', 'Pricing', 'Changelog', 'Roadmap']],
            ['LEARN', ['Docs', 'Guides', 'Discord', 'YouTube']],
            ['COMPANY', ['About', 'Privacy', 'Contact', 'Support']],
          ].map(([h, items]) => (
            <div key={h}>
              <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.1em', color: 'var(--ink-500)', marginBottom: 14 }}>{h}</div>
              {items.map(i => <div key={i} style={{ fontSize: 14, color: 'var(--ink-700)', padding: '4px 0', cursor: 'pointer' }}>{i}</div>)}
            </div>
          ))}
        </div>
        <div style={{ marginTop: 48, paddingTop: 20, borderTop: '1px solid var(--rule)', display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--ink-500)' }}>
          <span>© 2026 JT Power Tools · Made in Oklahoma</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}><span className="jt-dot"/>All systems running</span>
        </div>
      </footer>
    </div>
  );
}

window.LandingFrame = LandingFrame;
