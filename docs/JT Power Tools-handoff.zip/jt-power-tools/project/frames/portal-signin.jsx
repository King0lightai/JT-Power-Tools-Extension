/* global React */
// Portal sign-in — toolbox-feel front door

function PortalSignIn() {
  return (
    <div className="jt-frame" style={{ width: 1280, height: 820, display: 'flex', position: 'relative' }}>
      {/* Left — pitch */}
      <div style={{
        flex: '1 1 58%', padding: '56px 64px', position: 'relative',
        background: 'var(--ink-050)', display: 'flex', flexDirection: 'column',
        borderRight: '1px solid var(--rule)',
      }}>
        <div className="jt-tape" style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 8 }}/>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 'auto' }}>
          <div style={{ width: 40, height: 40, background: 'var(--flame)', display: 'grid', placeItems: 'center', borderRadius: 6, boxShadow: '0 2px 0 rgba(0,0,0,0.3)' }}>
            <span className="jt-display" style={{ fontSize: 20, color: '#0B0B0B' }}>JT</span>
          </div>
          <span className="jt-display" style={{ fontSize: 22, letterSpacing: '0.05em', color: 'var(--ink-900)' }}>POWER TOOLS</span>
        </div>

        <div>
          <div className="jt-eyebrow" style={{ marginBottom: 14 }}>The portal</div>
          <h1 className="jt-display" style={{ fontSize: 132, color: 'var(--ink-900)', lineHeight: 0.88, marginBottom: 28 }}>
            YOUR<br/>JOBTREAD,<br/>
            <span className="jt-serif" style={{ fontStyle: 'italic', color: 'var(--flame)' }}>souped&nbsp;up.</span>
          </h1>
          <p style={{ fontSize: 18, color: 'var(--ink-700)', maxWidth: 480, lineHeight: 1.55 }}>
            Sign in to manage your crew, connect AI helpers, and tweak your toolbox.
          </p>

          <div style={{ marginTop: 40, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            {[
              ['ph-wrench', '23 tools'],
              ['ph-users-three', 'Team seats'],
              ['ph-robot', 'AI ready'],
              ['ph-heart', '2,400+ contractors'],
            ].map(([i, t]) => (
              <div key={t} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 14px', background: 'var(--ink-100)', border: '1px solid var(--rule)', borderRadius: 20 }}>
                <i className={`ph ${i}`} style={{ color: 'var(--flame)', fontSize: 15 }}/>
                <span style={{ fontSize: 13, color: 'var(--ink-800)', fontWeight: 500 }}>{t}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right — form */}
      <div style={{
        flex: '1 1 42%', padding: '64px 72px', display: 'flex', flexDirection: 'column',
        background: 'var(--ink-100)', justifyContent: 'center',
      }}>
        <div className="jt-eyebrow" style={{ marginBottom: 8, color: 'var(--ink-500)' }}>Sign in</div>
        <h2 className="jt-display" style={{ fontSize: 56, color: 'var(--ink-900)', marginBottom: 8 }}>WELCOME BACK.</h2>
        <p style={{ fontSize: 15, color: 'var(--ink-600)', marginBottom: 36 }}>Pick up where you left off.</p>

        <label style={lbl}>Email</label>
        <input defaultValue="ryan@titus.co" style={inp}/>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 20 }}>
          <label style={lbl}>Password</label>
          <a style={{ fontSize: 12, color: 'var(--flame)', cursor: 'pointer', fontWeight: 600 }}>Forgot?</a>
        </div>
        <input type="password" defaultValue="••••••••••••" style={inp}/>

        <button style={primaryBtn}>
          Sign in
          <i className="ph ph-arrow-right" style={{ fontSize: 16 }}/>
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '24px 0' }}>
          <div style={{ flex: 1, height: 1, background: 'var(--rule)' }}/>
          <span style={{ fontSize: 11, color: 'var(--ink-500)', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase' }}>New here?</span>
          <div style={{ flex: 1, height: 1, background: 'var(--rule)' }}/>
        </div>

        <button style={secondaryBtn}>Create an account</button>

        <p style={{ marginTop: 28, fontSize: 12, color: 'var(--ink-500)', textAlign: 'center' }}>
          Don't have a license yet? <a style={{ color: 'var(--flame)', fontWeight: 600 }}>Get the tools →</a>
        </p>
      </div>
    </div>
  );
}

const lbl = { display: 'block', fontSize: 13, fontWeight: 600, color: 'var(--ink-700)', marginBottom: 8 };
const inp = {
  width: '100%', padding: '14px 16px', background: 'var(--ink-050)',
  border: '1px solid var(--rule)', color: 'var(--ink-900)',
  fontFamily: 'var(--font-ui)', fontSize: 15, outline: 'none', borderRadius: 6,
};
const primaryBtn = {
  marginTop: 28, padding: '16px 20px', background: 'var(--flame)', color: '#0B0B0B',
  border: 'none', borderRadius: 6, fontFamily: 'var(--font-ui)', fontSize: 15, fontWeight: 700,
  cursor: 'pointer', width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
  gap: 8, boxShadow: '0 2px 0 rgba(0,0,0,0.3)',
};
const secondaryBtn = {
  padding: '14px 20px', background: 'transparent', color: 'var(--ink-800)',
  border: '1px solid var(--rule)', borderRadius: 6, fontFamily: 'var(--font-ui)', fontSize: 14,
  fontWeight: 600, cursor: 'pointer', width: '100%',
};

window.PortalSignIn = PortalSignIn;
