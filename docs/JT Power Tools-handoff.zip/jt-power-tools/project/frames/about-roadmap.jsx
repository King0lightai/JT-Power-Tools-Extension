/* global React */
// About + Roadmap — contractor toolbox vibe

function AboutFrame() {
  return (
    <div className="jt-frame" style={{ width: 1280, height: 1700, background: 'var(--ink-050)' }}>
      <div className="jt-tape" style={{ height: 8 }}/>
      <nav style={{ display: 'flex', alignItems: 'center', padding: '18px 48px', borderBottom: '1px solid var(--rule)', background: 'var(--ink-100)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, background: 'var(--flame)', display: 'grid', placeItems: 'center', borderRadius: 4 }}>
            <span className="jt-display" style={{ fontSize: 17, color: '#0B0B0B' }}>JT</span>
          </div>
          <span className="jt-display" style={{ fontSize: 18, letterSpacing: '0.05em', color: 'var(--ink-900)' }}>POWER TOOLS</span>
        </div>
        <div style={{ display: 'flex', gap: 28, marginLeft: 64 }}>
          {['The tools', 'Pricing', 'Roadmap', 'About', 'Docs'].map(l => (
            <a key={l} style={{ fontSize: 14, color: l === 'About' ? 'var(--flame)' : 'var(--ink-700)', cursor: 'pointer', fontWeight: l === 'About' ? 700 : 500 }}>{l}</a>
          ))}
        </div>
      </nav>

      {/* Hero */}
      <section style={{ padding: '96px 48px 72px', borderBottom: '1px solid var(--rule)' }}>
        <div className="jt-eyebrow" style={{ marginBottom: 16 }}>Our story</div>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 56, alignItems: 'end' }}>
          <h1 className="jt-display" style={{ fontSize: 156, color: 'var(--ink-900)', lineHeight: 0.86 }}>
            BUILT IN THE<br/>
            <span className="jt-serif" style={{ fontStyle: 'italic', color: 'var(--flame)' }}>field,</span><br/>
            NOT A BOARDROOM.
          </h1>
          <p style={{ fontSize: 18, color: 'var(--ink-700)', lineHeight: 1.55, paddingBottom: 20 }}>
            A story about a construction IT lead who refused to settle for workarounds — and built the toolkit everyone else was waiting for.
          </p>
        </div>
      </section>

      {/* Story */}
      <section style={{ padding: '80px 48px', borderBottom: '1px solid var(--rule)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2.2fr', gap: 72 }}>
          <div>
            <div style={{ aspectRatio: '3/4', background: 'var(--ink-100)', border: '1px solid var(--rule)', borderRadius: 8, marginBottom: 16, display: 'grid', placeItems: 'center' }}>
              <div style={{ textAlign: 'center' }}>
                <i className="ph ph-user-circle" style={{ fontSize: 64, color: 'var(--ink-500)' }}/>
                <div style={{ fontSize: 12, color: 'var(--ink-600)', marginTop: 8 }}>(Portrait placeholder)</div>
              </div>
            </div>
            <div style={{ fontSize: 17, fontWeight: 700, color: 'var(--ink-900)' }}>Zeb Pierce</div>
            <div style={{ fontSize: 13, color: 'var(--ink-600)', marginTop: 4 }}>IT Director & Builder · Tulsa, OK</div>
          </div>
          <div>
            <h2 className="jt-display" style={{ fontSize: 56, color: 'var(--ink-900)', marginBottom: 28, lineHeight: 1 }}>
              IT STARTED WITH A <span style={{ color: 'var(--flame)' }}>CHECKBOX.</span>
            </h2>
            <p style={{ fontSize: 18, color: 'var(--ink-700)', lineHeight: 1.75, marginBottom: 20 }}>
              A dozen contractors on the JobTread forum asking for the same thing: <em className="jt-serif" style={{ fontSize: 20, color: 'var(--ink-900)' }}>"can we please just check off tasks on the schedule?"</em> Years went by. Nothing shipped.
            </p>
            <p style={{ fontSize: 18, color: 'var(--ink-700)', lineHeight: 1.75, marginBottom: 20 }}>
              So one weekend, I wrote a Chrome extension. Twenty lines of JavaScript. It worked. Then the next pain point. Then the next. Then a thousand users.
            </p>
            <p style={{ fontSize: 18, color: 'var(--ink-700)', lineHeight: 1.75, marginBottom: 36 }}>
              JT Power Tools is what happens when a contractor's IT lead stops asking nicely and starts building.
            </p>

            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.1em', color: 'var(--ink-500)', textTransform: 'uppercase', marginBottom: 14 }}>Pain points solved</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
              {[
                ['ph-clock', 'Slow schedules'],
                ['ph-text-t', 'No formatting'],
                ['ph-moon', 'Eye strain'],
                ['ph-broom', 'Clutter'],
              ].map(([i, l]) => (
                <div key={l} style={{ padding: 20, textAlign: 'center', background: 'var(--ink-100)', border: '1px solid var(--rule)', borderRadius: 8 }}>
                  <i className={`ph ${i}`} style={{ fontSize: 26, color: 'var(--flame)', marginBottom: 10 }}/>
                  <div style={{ fontSize: 13, color: 'var(--ink-900)', fontWeight: 600 }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section style={{ padding: '80px 48px', borderBottom: '1px solid var(--rule)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
          {[
            ['2,400+', 'Contractors using the tools'],
            ['23', 'Hacks in the toolbox'],
            ['3hrs', 'Saved per user per week'],
            ['4.9★', 'Average rating'],
          ].map(([n, l]) => (
            <div key={l} style={{ textAlign: 'center' }}>
              <div className="jt-display" style={{ fontSize: 96, color: 'var(--flame)', lineHeight: 0.9, marginBottom: 12 }}>{n}</div>
              <div style={{ fontSize: 13, color: 'var(--ink-600)' }}>{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: '80px 48px', textAlign: 'center' }}>
        <h2 className="jt-serif" style={{ fontSize: 64, color: 'var(--ink-900)', marginBottom: 16, fontStyle: 'italic', lineHeight: 1.05 }}>
          Got a JobTread gripe?<br/>Let's fix it.
        </h2>
        <p style={{ fontSize: 16, color: 'var(--ink-600)', marginBottom: 28 }}>
          Every shipped tool started as someone complaining on Discord.
        </p>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <button style={{ padding: '14px 24px', background: 'var(--flame)', color: '#0B0B0B', border: 'none', borderRadius: 6, fontSize: 14, fontWeight: 700, cursor: 'pointer', boxShadow: '0 2px 0 rgba(0,0,0,0.3)' }}>
            Join our Discord
          </button>
          <button style={{ padding: '14px 24px', background: 'transparent', color: 'var(--ink-900)', border: '1px solid var(--rule)', borderRadius: 6, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
            Email the team
          </button>
        </div>
      </section>
    </div>
  );
}

function RoadmapFrame() {
  return (
    <div className="jt-frame" style={{ width: 1280, height: 1900, background: 'var(--ink-050)' }}>
      <div className="jt-tape" style={{ height: 8 }}/>
      <nav style={{ display: 'flex', alignItems: 'center', padding: '18px 48px', borderBottom: '1px solid var(--rule)', background: 'var(--ink-100)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, background: 'var(--flame)', display: 'grid', placeItems: 'center', borderRadius: 4 }}>
            <span className="jt-display" style={{ fontSize: 17, color: '#0B0B0B' }}>JT</span>
          </div>
          <span className="jt-display" style={{ fontSize: 18, letterSpacing: '0.05em', color: 'var(--ink-900)' }}>POWER TOOLS</span>
        </div>
        <div style={{ display: 'flex', gap: 28, marginLeft: 64 }}>
          {['The tools', 'Pricing', 'Roadmap', 'About', 'Docs'].map(l => (
            <a key={l} style={{ fontSize: 14, color: l === 'Roadmap' ? 'var(--flame)' : 'var(--ink-700)', cursor: 'pointer', fontWeight: l === 'Roadmap' ? 700 : 500 }}>{l}</a>
          ))}
        </div>
      </nav>

      {/* Hero */}
      <section style={{ padding: '96px 48px 56px', borderBottom: '1px solid var(--rule)' }}>
        <div className="jt-eyebrow" style={{ marginBottom: 16 }}>Roadmap · Updated weekly</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 56, alignItems: 'end' }}>
          <h1 className="jt-display" style={{ fontSize: 156, color: 'var(--ink-900)', lineHeight: 0.86 }}>
            WHAT'S BUILT.<br/>WHAT'S <span style={{ color: 'var(--flame)' }}>NEXT.</span>
          </h1>
          <p style={{ fontSize: 17, color: 'var(--ink-700)', lineHeight: 1.55, paddingBottom: 20 }}>
            Public and honest. Vote on our Discord — the features with the most 👍 jump the queue.
          </p>
        </div>
      </section>

      {/* Kanban-style columns */}
      <section style={{ padding: '64px 48px', borderBottom: '1px solid var(--rule)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18 }}>
          {[
            {
              title: 'Shipped', sub: 'Already in the toolbox', color: 'var(--green)',
              items: [
                ['Vendor bill forwarding', 'Apr 2026'],
                ['AI helper launch', 'Feb 2026'],
                ['Team accounts', 'Dec 2025'],
                ['PDF markup tools', 'Oct 2025'],
                ['Custom theme colors', 'Aug 2025'],
              ],
            },
            {
              title: 'Building now', sub: 'Current sprint', color: 'var(--flame)',
              items: [
                ['Vendor allowlist', 'Next week'],
                ['Inbound bill parsing', 'This month'],
                ['Faster AI responses', 'This month'],
              ],
            },
            {
              title: 'Up next', sub: 'Planned Q3', color: 'var(--yellow-tape)',
              items: [
                ['Knowledge base', 'Summer'],
                ['Document ingestion', 'Summer'],
                ['Semantic job search', 'Summer'],
                ['Budget snapshots', 'Summer'],
              ],
            },
            {
              title: 'Exploring', sub: 'Thinking about it', color: 'var(--ink-500)',
              items: [
                ['Mobile companion app', 'Maybe'],
                ['Voice quick notes', 'Maybe'],
                ['Public API', 'Maybe'],
                ['Offline mode', 'Maybe'],
              ],
            },
          ].map(col => (
            <div key={col.title} style={{ background: 'var(--ink-100)', border: '1px solid var(--rule)', borderRadius: 10, overflow: 'hidden' }}>
              <div style={{ padding: '16px 18px', borderBottom: '1px solid var(--rule)', background: 'var(--ink-050)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: col.color }}/>
                  <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink-900)' }}>{col.title}</span>
                  <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--ink-500)', fontWeight: 600 }}>{col.items.length}</span>
                </div>
                <div style={{ fontSize: 12, color: 'var(--ink-600)' }}>{col.sub}</div>
              </div>
              <div style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
                {col.items.map(([t, when]) => (
                  <div key={t} style={{ padding: '12px 14px', background: 'var(--ink-050)', border: '1px solid var(--rule-soft)', borderRadius: 6 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink-900)', marginBottom: 4 }}>{t}</div>
                    <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>{when}</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Vote CTA */}
      <section style={{ padding: '80px 48px', textAlign: 'center' }}>
        <h2 className="jt-serif" style={{ fontSize: 60, color: 'var(--ink-900)', marginBottom: 16, fontStyle: 'italic', lineHeight: 1.05 }}>
          Want something built?<br/>Ask for it.
        </h2>
        <p style={{ fontSize: 16, color: 'var(--ink-600)', maxWidth: 560, margin: '0 auto 28px' }}>
          Every shipped tool started as a suggestion. Your workflow problem is probably someone else's too.
        </p>
        <button style={{ padding: '16px 28px', background: 'var(--flame)', color: '#0B0B0B', border: 'none', borderRadius: 6, fontSize: 15, fontWeight: 700, cursor: 'pointer', boxShadow: '0 3px 0 rgba(0,0,0,0.3)' }}>
          <i className="ph ph-discord-logo" style={{ marginRight: 10, fontSize: 18 }}/>Suggest on Discord
        </button>
      </section>
    </div>
  );
}

window.AboutFrame = AboutFrame;
window.RoadmapFrame = RoadmapFrame;
