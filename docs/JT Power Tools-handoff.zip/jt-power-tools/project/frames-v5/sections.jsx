/* global React */
// v5 — Install row, MCP/AI, How It Works, Reviews, Pricing, CTA, Footer

function InstallRowV5() {
  const rows = [
    ['ph-google-chrome-logo', 'Chrome', '', true],
    ['ph-browser', 'Edge', '', true],
    ['ph-firefox-logo', 'Firefox', '', true],
    ['ph-apple-logo', 'Safari', 'Soon', false],
  ];
  return (
    <section style={{ padding: '88px 48px', borderBottom: '1px solid var(--rule)', background: 'var(--bg-surface)' }}>
      <div style={{ textAlign: 'center', marginBottom: 40 }}>
        <div className="jt-eyebrow" style={{ marginBottom: 10 }}>Install</div>
        <h2 className="jt-display" style={{ fontSize: 76, color: 'var(--fg-strong)' }}>
          EVERYWHERE <span style={{ color: 'var(--accent)' }}>YOU WORK</span>
        </h2>
      </div>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap', maxWidth: 880, margin: '0 auto' }}>
        {rows.map(([icon, name, note, live]) => (
          <a key={name} className="jt-btn" style={{
            background: live ? 'var(--bg-inverse)' : 'var(--bg-raised)',
            color: live ? 'var(--fg-inverse)' : 'var(--fg-muted)',
            fontSize: 14, padding: '14px 22px',
            opacity: live ? 1 : 0.7,
            border: '1px solid ' + (live ? 'transparent' : 'var(--rule)'),
          }}>
            <i className={`ph ${icon}`} style={{ fontSize: 18 }}/>
            {name} {note && <span style={{ opacity: 0.6 }}>— {note}</span>}
          </a>
        ))}
      </div>
      <div style={{ textAlign: 'center', marginTop: 24, fontSize: 13, color: 'var(--fg-subtle)' }}>
        Use <strong style={{ color: 'var(--fg)' }}>Brave, Arc, or Opera</strong>? Choose Chrome — same store. · Safari supports extensions on iPhone & iPad.
      </div>
    </section>
  );
}

function McpV5() {
  const tools = [
    ['jt_job_context', 'ph-folder', 'Job + budget + schedule + docs in one grab. Because nobody actually wants just the job record.'],
    ['jt_financial_context', 'ph-chart-pie', 'The rollup already calculated — not raw ledger entries the AI has to assemble.'],
    ['jt_schedule_context', 'ph-calendar', 'Crew + tasks + dates stitched together the way you actually read a schedule.'],
    ['jt_search', 'ph-magnifying-glass', "Cross-entity search. You don't have to know which dataset the thing lives in before you look for it."],
    ['ctx_batch', 'ph-stack', 'Run a stack of calls in one request when you need to. No ten-round-trip dance.'],
    ['ctx_index / ctx_search', 'ph-brain', "Knowledge base that remembers what you figured out last time. Stop re-deriving context every session."],
  ];

  const prompts = [
    "Compare this bid request against the project scope",
    "Pull key metrics for my production meeting",
    "Forecast labor needs for the next 2 weeks",
    "Pull historical budget data to cost a new project",
  ];

  return (
    <section className="jt-blueprint" style={{ padding: '104px 48px', position: 'relative', overflow: 'hidden' }}>
      {/* Safety-tape strip top */}
      <div className="jt-safety-tape" style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 6 }}/>

      {/* ── Section header ── */}
      <div style={{ maxWidth: 1100, margin: '0 auto 56px' }}>
        <div style={{
          fontFamily: 'var(--ff-mono)', fontSize: 11, color: '#8eb0ff',
          letterSpacing: '0.2em', marginBottom: 18, textTransform: 'uppercase',
        }}>
          AI Toolkit · Included with Power User
        </div>

        <h2 className="jt-display" style={{ fontSize: 108, color: '#fff', marginBottom: 26, lineHeight: 0.9 }}>
          YOUR AI NEEDS A<br/>
          <span style={{ color: 'var(--jt-orange)' }}>TOOLBELT,</span>{' '}
          <span className="jt-serif" style={{
            fontFamily: 'var(--ff-serif)', fontStyle: 'italic',
            fontWeight: 400, color: 'rgba(255,255,255,0.85)',
            textTransform: 'none', fontSize: 96, letterSpacing: '-0.01em',
          }}>not an apprentice.</span>
        </h2>

        <p style={{ fontSize: 19, color: 'rgba(255,255,255,0.75)', lineHeight: 1.55, maxWidth: 780 }}>
          JobTread shipped a great official MCP — it's the truck, it has every tool their API exposes.
          Ours is the toolbelt: purpose-built, pre-loaded, staged right where the work happens.
          Your AI stops asking five follow-up questions and starts answering the first one.
        </p>
      </div>

      {/* ── Breadth vs depth card ── */}
      <div style={{
        maxWidth: 1100, margin: '0 auto 56px',
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0,
        background: 'rgba(255,255,255,0.04)',
        border: '1px solid rgba(255,255,255,0.14)',
        borderRadius: 14, overflow: 'hidden',
      }}>
        <div style={{ padding: '32px 36px', borderRight: '1px solid rgba(255,255,255,0.12)' }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14,
          }}>
            <div style={{
              width: 32, height: 32, borderRadius: 6,
              background: 'rgba(255,255,255,0.08)',
              display: 'grid', placeItems: 'center',
            }}>
              <i className="ph ph-cloud" style={{ fontSize: 18, color: 'rgba(255,255,255,0.7)' }}/>
            </div>
            <span className="jt-display-upright" style={{ fontSize: 18, color: '#fff', letterSpacing: '0.04em' }}>
              OFFICIAL JOBTREAD MCP
            </span>
          </div>
          <div style={{ fontSize: 13, color: '#8eb0ff', fontFamily: 'var(--ff-mono)', marginBottom: 10, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
            The truck · breadth
          </div>
          <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.78)', lineHeight: 1.55 }}>
            Commodity access to the Pave API. Every field JobTread exposes, one query at a time.
            Great for the AI that already knows exactly what to ask for.
          </p>
        </div>
        <div style={{ padding: '32px 36px', background: 'rgba(254, 76, 13, 0.08)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
            <div style={{
              width: 32, height: 32, borderRadius: 6,
              background: 'var(--jt-orange)',
              display: 'grid', placeItems: 'center',
              boxShadow: '0 2px 0 var(--jt-orange-deep)',
            }}>
              <i className="ph ph-wrench" style={{ fontSize: 18, color: '#fff' }}/>
            </div>
            <span className="jt-display-upright" style={{ fontSize: 18, color: '#fff', letterSpacing: '0.04em' }}>
              JT POWER TOOLS MCP
            </span>
          </div>
          <div style={{ fontSize: 13, color: 'var(--jt-orange)', fontFamily: 'var(--ff-mono)', marginBottom: 10, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
            The toolbelt · depth
          </div>
          <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.92)', lineHeight: 1.55 }}>
            Workflow intelligence layer. Batching, context bundling, intent-based trimming —
            the joins you always need, pre-joined. The work arranged the way the work actually flows.
          </p>
        </div>
      </div>

      {/* ── Tool cards ── */}
      <div style={{ maxWidth: 1100, margin: '0 auto 56px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 16, marginBottom: 22, borderBottom: '1px solid rgba(255,255,255,0.15)', paddingBottom: 16 }}>
          <span style={{ fontFamily: 'var(--ff-mono)', fontSize: 12, color: 'var(--jt-orange)', fontWeight: 600, letterSpacing: '0.05em' }}>06</span>
          <span className="jt-display-upright" style={{ fontSize: 22, color: '#fff', letterSpacing: '0.04em' }}>WHAT'S IN THE TOOLBELT</span>
          <span style={{ marginLeft: 'auto', fontSize: 13, color: 'rgba(255,255,255,0.55)', fontFamily: 'var(--ff-serif)', fontStyle: 'italic' }}>
            Same Pave API underneath. Arranged the way you actually work.
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {tools.map(([name, icon, desc]) => (
            <div key={name} style={{
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.14)',
              borderRadius: 10, padding: '22px 22px 24px',
              backdropFilter: 'blur(6px)',
              position: 'relative',
            }}>
              <div style={{
                width: 38, height: 38, borderRadius: 8,
                background: 'rgba(254, 76, 13, 0.15)',
                border: '1px solid rgba(254, 76, 13, 0.35)',
                display: 'grid', placeItems: 'center',
                marginBottom: 14,
              }}>
                <i className={`ph ${icon}`} style={{ fontSize: 20, color: 'var(--jt-orange)' }}/>
              </div>
              <div style={{
                fontFamily: 'var(--ff-mono)', fontSize: 13, fontWeight: 600,
                color: '#fff', marginBottom: 8, letterSpacing: '-0.01em',
              }}>
                {name}
              </div>
              <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.72)', lineHeight: 1.55, margin: 0 }}>{desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── The "why this matters" callout ── */}
      <div style={{
        maxWidth: 880, margin: '0 auto 56px',
        padding: '32px 40px',
        background: 'rgba(0, 0, 0, 0.35)',
        border: '1px solid rgba(255,255,255,0.12)',
        borderLeft: '3px solid var(--jt-orange)',
        borderRadius: 8,
      }}>
        <div style={{ fontSize: 12, fontFamily: 'var(--ff-mono)', color: 'var(--jt-orange)', letterSpacing: '0.15em', marginBottom: 12, textTransform: 'uppercase' }}>
          Here's the thing
        </div>
        <p className="jt-serif" style={{
          fontSize: 26, color: '#fff', lineHeight: 1.45, margin: 0,
          fontStyle: 'italic', fontWeight: 400,
        }}>
          People on the JT Facebook group are hitting usage limits and their AI is slow, so they end up
          doing it manually anyway. AI can learn — but nobody has time to train it to fetch the right
          data the first time.
        </p>
        <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.78)', lineHeight: 1.6, marginTop: 18, marginBottom: 0 }}>
          The toolbelt is our answer. Pre-trained context. Pre-built joins. Batched calls. A knowledge
          index that remembers what you figured out last Tuesday so you're not re-deriving it Monday.
          <strong style={{ color: '#fff' }}> Your AI should walk into the job with the right tools already in hand.</strong>
        </p>
      </div>

      {/* ── Prompts ── */}
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontFamily: 'var(--ff-mono)', fontSize: 11, color: '#8eb0ff', letterSpacing: '0.2em', marginBottom: 16, textTransform: 'uppercase' }}>
          Prompts that work on day one
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap', maxWidth: 1000, margin: '0 auto 28px' }}>
          {prompts.map(p => (
            <span key={p} style={{
              padding: '10px 18px',
              background: 'rgba(255, 255, 255, 0.08)',
              border: '1px solid rgba(255, 255, 255, 0.18)',
              borderRadius: 999,
              fontSize: 15, color: '#fff',
              fontFamily: 'var(--ff-serif)', fontStyle: 'italic',
            }}>
              "{p}"
            </span>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap', marginTop: 24 }}>
          {['ChatGPT', 'Claude', 'Gemini', 'Grok', 'Cursor', 'Claude Code'].map(c => (
            <span key={c} style={{
              padding: '8px 14px',
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.15)',
              borderRadius: 6,
              fontSize: 12, color: 'rgba(255,255,255,0.85)',
              fontWeight: 600, letterSpacing: '0.02em',
            }}>
              <i className="ph ph-plugs-connected" style={{ fontSize: 13, marginRight: 6, color: 'var(--jt-orange)' }}/>
              {c}
            </span>
          ))}
        </div>
        <div style={{ marginTop: 16, fontSize: 13, color: 'rgba(255,255,255,0.55)' }}>
          Connects to every major AI client via MCP. OAuth in seconds; bearer token for CLI.
        </div>
      </div>
    </section>
  );
}

function HowItWorksV5() {
  const steps = [
    ['Install', 'Add JT Power Tools from the Chrome Web Store. One click, no signup required.'],
    ['Navigate', 'Go to JobTread and click the extension icon in your toolbar.'],
    ['Toggle', 'Enable the features you want. Settings save automatically and sync across devices.'],
    ['Power Up', 'Start working faster with your new superpowers. Features activate instantly.'],
  ];
  return (
    <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--rule)' }}>
      <div style={{ textAlign: 'center', marginBottom: 56 }}>
        <div className="jt-eyebrow" style={{ marginBottom: 10 }}>How it works</div>
        <h2 className="jt-display" style={{ fontSize: 76, color: 'var(--fg-strong)' }}>
          UP AND RUNNING <span style={{ color: 'var(--accent)' }}>IN MINUTES</span>
        </h2>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20, maxWidth: 1100, margin: '0 auto' }}>
        {steps.map(([name, desc], i) => (
          <div key={name} style={{ position: 'relative' }}>
            <div style={{
              fontFamily: 'var(--ff-display)', fontStyle: 'italic', fontWeight: 700,
              fontSize: 96, color: 'var(--accent)', lineHeight: 1,
              opacity: 0.9,
            }}>{i + 1}</div>
            <h3 className="jt-display-upright" style={{ fontSize: 24, color: 'var(--fg-strong)', margin: '10px 0 8px', letterSpacing: '0.03em' }}>
              {name.toUpperCase()}
            </h3>
            <p style={{ fontSize: 14, color: 'var(--fg-muted)', lineHeight: 1.55 }}>{desc}</p>
            {i < steps.length - 1 && (
              <i className="ph ph-arrow-right" style={{ position: 'absolute', top: 50, right: -12, fontSize: 20, color: 'var(--rule-strong)' }}/>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

function ReviewsV5() {
  return (
    <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--rule)', background: 'var(--bg-surface)' }}>
      <div style={{ textAlign: 'center', marginBottom: 56 }}>
        <div className="jt-eyebrow" style={{ marginBottom: 10 }}>Reviews</div>
        <h2 className="jt-display" style={{ fontSize: 76, color: 'var(--fg-strong)' }}>
          WHAT CONTRACTORS <span style={{ color: 'var(--accent)' }}>ARE SAYING</span>
        </h2>
        <p style={{ fontSize: 15, color: 'var(--fg-muted)', marginTop: 12 }}>Real feedback from the Chrome Web Store</p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, maxWidth: 1000, margin: '0 auto' }}>
        {[
          ['"This is a badass extension for JobTread! Thank you so much for these tools!"', 'Chris Uhler', 'December 2, 2025', 'CU'],
          ['"My Eyes!!!!! Love the dark mode. I\'ll be showing this to my other estimator this week!"', 'Brendan McConkie', 'November 16, 2025', 'BM'],
        ].map(([quote, name, date, initials]) => (
          <div key={name} className="jt-card" style={{ padding: 32 }}>
            <div style={{ color: 'var(--accent)', fontSize: 18, marginBottom: 14, letterSpacing: '0.08em' }}>★★★★★</div>
            <p className="jt-serif" style={{ fontSize: 22, color: 'var(--fg-strong)', lineHeight: 1.45, marginBottom: 22 }}>{quote}</p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'var(--accent)', color: 'var(--accent-fg)', display: 'grid', placeItems: 'center', fontFamily: 'var(--ff-display)', fontStyle: 'italic', fontSize: 14, fontWeight: 700 }}>{initials}</div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--fg-strong)' }}>{name}</div>
                <div style={{ fontSize: 12, color: 'var(--fg-subtle)' }}>{date}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ textAlign: 'center', marginTop: 32 }}>
        <a className="jt-btn jt-btn-ghost" style={{ fontSize: 14 }}>See all reviews on Chrome Web Store →</a>
      </div>
      <div style={{ textAlign: 'center', marginTop: 18, fontSize: 14, color: 'var(--fg-muted)' }}>
        Join <strong style={{ color: 'var(--fg-strong)' }}>400+</strong> contractors already using JT Power Tools
      </div>
    </section>
  );
}

window.InstallRowV5 = InstallRowV5;
window.McpV5 = McpV5;
window.HowItWorksV5 = HowItWorksV5;
window.ReviewsV5 = ReviewsV5;
