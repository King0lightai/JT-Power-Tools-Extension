/* global React */
// v5 — Pricing, CTA, Footer

function PricingV5() {
  const tiers = [
    { name: 'Free', price: '$0', period: '', desc: 'Core tools to get started', cta: 'Install Free', tone: 'free', feats: [
      'Text Formatter', 'Dark Mode', 'Contrast Fix', 'Character Counter & Templates',
      'Budget Hierarchy Shading', 'Budget Auto Sum', 'Kanban Type Filter', 'Auto Collapse Groups',
    ]},
    { name: 'Essential', price: '$10', period: '/mo', desc: 'Productivity tools for teams', cta: 'Get Essential', tone: 'essential', feats: [
      'Everything in Free', 'Quick Notes', 'Smart Resize', 'Freeze Header', 'PDF Markup Tools', 'Reverse Thread Order',
    ]},
    { name: 'Pro', price: '$20', period: '/mo', desc: 'Power users & customization', cta: 'Get Pro', tone: 'pro', feats: [
      'Everything in Essential', 'Schedule & Task Checkboxes', 'Custom Theme (3 slots)', 'Preview Mode', 'Availability Filter',
    ]},
    { name: 'Power User', price: '$30', period: '/mo', desc: 'API-powered features', cta: 'Get Power User', tone: 'power', featured: true, feats: [
      'Everything in Pro', 'Job Switcher Filter', 'Budget Changelog', 'Unassigned Availability', 'MCP Server Access',
    ]},
  ];
  const toneColor = { free: 'var(--fg-muted)', essential: '#00a87a', pro: 'var(--accent)', power: '#C850FF' };

  return (
    <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--rule)' }}>
      <div style={{ textAlign: 'center', marginBottom: 20 }}>
        <div className="jt-eyebrow" style={{ marginBottom: 12 }}>Pricing</div>
        <h2 className="jt-display" style={{ fontSize: 84, color: 'var(--fg-strong)' }}>
          CHOOSE <span style={{ color: 'var(--accent)' }}>YOUR PLAN</span>
        </h2>
        <p style={{ fontSize: 16, color: 'var(--fg-muted)', marginTop: 10 }}>One subscription covers your entire organization</p>

        {/* Billing toggle */}
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 14, marginTop: 22 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--fg-strong)' }}>Monthly</span>
          <div style={{
            width: 52, height: 28, borderRadius: 20,
            background: 'var(--bg-raised)', border: '2px solid var(--rule)',
            position: 'relative', cursor: 'pointer',
          }}>
            <div style={{ position: 'absolute', top: 2, left: 2, width: 20, height: 20, borderRadius: '50%', background: '#fff' }}/>
          </div>
          <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--fg-muted)' }}>
            Yearly <span style={{ padding: '2px 8px', background: 'var(--jt-green)', color: '#000', fontSize: 11, fontWeight: 800, borderRadius: 10, marginLeft: 4 }}>Save 17%</span>
          </span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginTop: 40, maxWidth: 1200, margin: '40px auto 0' }}>
        {tiers.map(t => (
          <div key={t.name} className="jt-card" style={{
            padding: '28px 24px', position: 'relative',
            borderWidth: t.featured ? 2 : 1,
            borderColor: t.featured ? toneColor[t.tone] : undefined,
            borderStyle: 'solid',
          }}>
            {t.featured && <div style={{ position: 'absolute', top: -12, left: 20, padding: '4px 10px', background: toneColor[t.tone], color: '#fff', fontSize: 10, fontWeight: 800, borderRadius: 10, letterSpacing: '0.12em', textTransform: 'uppercase' }}>Most popular</div>}
            <div style={{ fontFamily: 'var(--ff-mono)', fontSize: 11, fontWeight: 700, color: toneColor[t.tone], letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: 8 }}>{t.name}</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 4 }}>
              <span className="jt-display" style={{ fontSize: 56, color: 'var(--fg-strong)', fontStyle: 'normal' }}>{t.price}</span>
              <span style={{ fontSize: 13, color: 'var(--fg-muted)' }}>{t.period}</span>
            </div>
            <p style={{ fontSize: 13, color: 'var(--fg-muted)', marginBottom: 18, minHeight: 36 }}>{t.desc}</p>
            <button style={{
              width: '100%', padding: 12, marginBottom: 20,
              border: `2px solid ${toneColor[t.tone]}`,
              background: 'transparent', color: toneColor[t.tone],
              fontFamily: 'var(--ff-body)', fontSize: 13, fontWeight: 700,
              borderRadius: 8, cursor: 'pointer',
            }}>{t.cta}</button>
            <div style={{ borderTop: '1px solid var(--rule-soft)', paddingTop: 14 }}>
              {t.feats.map((f, i) => (
                <div key={f} style={{
                  display: 'flex', gap: 10, padding: '5px 0',
                  fontSize: 13, color: 'var(--fg)',
                  fontWeight: i === t.feats.length - 1 && t.tone === 'power' ? 700 : 400,
                }}>
                  <i className="ph ph-check" style={{ color: toneColor[t.tone], fontSize: 14, marginTop: 3, flexShrink: 0 }}/>
                  {f}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div style={{ textAlign: 'center', fontSize: 13, color: 'var(--fg-subtle)', marginTop: 24 }}>
        Powered by <span style={{ color: '#ff90e8', fontWeight: 700 }}>Gumroad</span>
      </div>

      <div style={{
        marginTop: 36, padding: '20px 28px',
        background: 'var(--accent-wash)',
        border: '1px solid var(--accent-ink)',
        borderRadius: 12, maxWidth: 720, margin: '36px auto 0',
        textAlign: 'center',
      }}>
        <div className="jt-display-upright" style={{ fontSize: 18, color: 'var(--accent-ink)', marginBottom: 6, letterSpacing: '0.04em' }}>
          ONE SUBSCRIPTION, UNLIMITED USERS
        </div>
        <p style={{ fontSize: 14, color: 'var(--fg)', lineHeight: 1.55 }}>
          Your subscription covers your entire organization. Share with all employees who need access — no per-user fees, no hidden costs. Cancel anytime.
        </p>
      </div>
    </section>
  );
}

function CtaV5() {
  return (
    <section style={{ padding: '96px 48px', background: 'var(--bg-inverse)', color: 'var(--fg-inverse)' }}>
      <div style={{ textAlign: 'center', maxWidth: 860, margin: '0 auto' }}>
        <h2 className="jt-display" style={{ fontSize: 88, color: 'var(--fg-inverse)', marginBottom: 16, lineHeight: 0.9 }}>
          READY TO POWER UP<br/>
          <span style={{ color: 'var(--jt-orange)' }}>YOUR JOBTREAD?</span>
        </h2>
        <p style={{ fontSize: 17, color: 'rgba(255,255,255,0.7)', marginBottom: 36 }}>
          Join contractors who are already working smarter, not harder. Install in seconds.
        </p>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
          <a className="jt-btn jt-btn-primary" style={{ fontSize: 15, padding: '16px 24px' }}>
            <i className="ph ph-google-chrome-logo" style={{ fontSize: 18 }}/> Install for Chrome
          </a>
          <a className="jt-btn" style={{ fontSize: 15, padding: '16px 24px', background: 'rgba(255,255,255,0.08)', color: '#fff', border: '1px solid rgba(255,255,255,0.2)' }}>
            <i className="ph ph-browser" style={{ fontSize: 18 }}/> Install for Edge
          </a>
          <a className="jt-btn" style={{ fontSize: 15, padding: '16px 24px', background: 'rgba(255,255,255,0.08)', color: '#fff', border: '1px solid rgba(255,255,255,0.2)' }}>
            <i className="ph ph-firefox-logo" style={{ fontSize: 18 }}/> Install for Firefox
          </a>
        </div>
      </div>
    </section>
  );
}

function FooterV5() {
  return (
    <footer style={{ padding: '40px 48px 28px', background: 'var(--bg-surface)', borderTop: '1px solid var(--rule)' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr auto', gap: 32, alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div className="jt-gear" style={{ width: 40, height: 40 }}/>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.15em', color: 'var(--accent)', textTransform: 'uppercase' }}>Official JobTread Partner</div>
            <div style={{ fontSize: 13, color: 'var(--fg-muted)', marginTop: 2 }}>Made with care for JobTread users</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 20, justifyContent: 'center', fontSize: 13 }}>
          {['What\'s New', 'Feedback', 'Facebook', 'Discord', 'Docs'].map(l => (
            <a key={l} style={{ color: 'var(--fg-muted)', cursor: 'pointer' }}>{l}</a>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 16, fontSize: 13 }}>
          {['Privacy', 'About', 'GitHub'].map(l => (
            <a key={l} style={{ color: 'var(--fg-subtle)', cursor: 'pointer' }}>{l}</a>
          ))}
        </div>
      </div>
    </footer>
  );
}

function BeforeAfterV5() {
  return (
    <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--rule)' }}>
      <div style={{ textAlign: 'center', marginBottom: 48 }}>
        <div className="jt-eyebrow" style={{ marginBottom: 12 }}>The difference</div>
        <h2 className="jt-display" style={{ fontSize: 84, color: 'var(--fg-strong)' }}>
          JOBTREAD, <span style={{ fontFamily: 'var(--ff-serif)', fontStyle: 'italic', fontWeight: 400, color: 'var(--fg-muted)' }}>now with power tools.</span>
        </h2>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {[
          { label: 'STANDARD JOBTREAD', tone: 'muted', items: [
            ['ph-x', 'Open task cards individually to check them off'],
            ['ph-x', 'Plain text fields for notes and budget descriptions'],
            ['ph-x', 'Type the same signature and canned replies every time'],
            ['ph-x', 'Re-type messages to count characters'],
            ['ph-x', 'Jump to another tab to ask AI about your data'],
          ]},
          { label: 'WITH POWER TOOLS', tone: 'flame', items: [
            ['ph-check', 'Checkboxes on schedule cards — one click, no modal'],
            ['ph-check', 'Rich text with lists, colors, tables, headings'],
            ['ph-check', 'Saved templates paste in one click'],
            ['ph-check', 'Live character counter on every message field'],
            ['ph-check', 'ChatGPT, Claude, Gemini read your jobs directly'],
          ]},
        ].map(col => (
          <div key={col.label} style={{
            background: col.tone === 'flame' ? 'var(--accent-wash)' : 'var(--bg-raised)',
            border: `1px solid ${col.tone === 'flame' ? 'var(--accent-ink)' : 'var(--rule)'}`,
            borderRadius: 14, padding: 32,
          }}>
            <div style={{
              fontFamily: 'var(--ff-mono)', fontSize: 11, fontWeight: 700,
              letterSpacing: '0.15em', textTransform: 'uppercase',
              color: col.tone === 'flame' ? 'var(--accent-ink)' : 'var(--fg-subtle)',
              marginBottom: 20,
            }}>{col.label}</div>
            {col.items.map(([icon, text], i) => (
              <div key={i} style={{
                display: 'flex', gap: 14, padding: '14px 0',
                borderTop: i === 0 ? 'none' : '1px solid var(--rule-soft)',
                alignItems: 'flex-start',
              }}>
                <i className={`ph ${icon}`} style={{
                  fontSize: 18, marginTop: 3, flexShrink: 0,
                  color: col.tone === 'flame' ? 'var(--accent)' : 'var(--fg-subtle)',
                }}/>
                <span style={{
                  fontSize: 15, lineHeight: 1.5,
                  color: col.tone === 'flame' ? 'var(--fg-strong)' : 'var(--fg-muted)',
                }}>{text}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </section>
  );
}

window.PricingV5 = PricingV5;
window.CtaV5 = CtaV5;
window.FooterV5 = FooterV5;
window.BeforeAfterV5 = BeforeAfterV5;
