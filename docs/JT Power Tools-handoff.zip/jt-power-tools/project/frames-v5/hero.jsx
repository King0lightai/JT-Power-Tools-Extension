/* global React */
// v5 — Nav + Hero. Real logo, real tagline, real voice.

function NavV5({ theme, onToggleTheme, active }) {
  return (
    <nav style={{
      display: 'flex', alignItems: 'center', gap: 0,
      padding: '16px 48px',
      borderBottom: '1px solid var(--rule)',
      background: 'var(--bg)',
      position: 'relative', zIndex: 10,
    }}>
      <a href="#" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
        <div className="jt-gear" style={{ width: 38, height: 38 }}/>
        <span className="jt-display" style={{ fontSize: 22, color: 'var(--fg-strong)' }}>
          POWER TOOLS
        </span>
      </a>
      <div style={{ display: 'flex', gap: 28, marginLeft: 56 }}>
        {['Features', 'Install', 'Pricing', 'AI', 'Roadmap', 'About'].map(l => (
          <a key={l} style={{
            fontSize: 14,
            color: active === l ? 'var(--accent-ink)' : 'var(--fg)',
            fontWeight: active === l ? 700 : 500,
            cursor: 'pointer',
          }}>{l}</a>
        ))}
      </div>
      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 10 }}>
        <button onClick={onToggleTheme} style={{
          display: 'flex', alignItems: 'center', gap: 6,
          padding: '8px 12px',
          background: 'var(--bg-raised)', border: '1px solid var(--rule)',
          color: 'var(--fg-muted)', fontSize: 12, fontWeight: 600,
          borderRadius: 'var(--r-pill)', cursor: 'pointer',
        }}>
          <i className={`ph ${theme === 'dark' ? 'ph-sun' : 'ph-moon'}`} style={{ color: 'var(--accent-ink)', fontSize: 14 }}/>
          {theme === 'dark' ? 'Light' : 'Dark'}
        </button>
        <a className="jt-btn jt-btn-primary" style={{ fontSize: 13 }}>
          <i className="ph ph-download-simple"/> Install Free
        </a>
      </div>
    </nav>
  );
}

function HeroV5() {
  return (
    <section style={{ padding: '80px 48px 60px', borderBottom: '1px solid var(--rule)', position: 'relative', overflow: 'hidden' }}>
      {/* Faint gear echo in the bg */}
      <div className="jt-gear" style={{
        position: 'absolute', top: -120, right: -120,
        width: 560, height: 560, opacity: 0.05,
        transform: 'rotate(18deg)',
        pointerEvents: 'none',
      }}/>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 64, alignItems: 'center', position: 'relative' }}>
        <div>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            padding: '6px 12px', marginBottom: 28,
            background: 'var(--accent-wash)',
            border: '1px solid var(--accent-ink)',
            borderRadius: 'var(--r-pill)',
            fontSize: 11, fontWeight: 700, letterSpacing: '0.12em',
            textTransform: 'uppercase', color: 'var(--accent-ink)',
          }}>
            <i className="ph ph-seal-check" style={{ fontSize: 13 }}/>
            Official JobTread Partner
          </div>

          <h1 className="jt-display" style={{
            fontSize: 116, lineHeight: 0.88,
            color: 'var(--fg-strong)',
            marginBottom: 24,
          }}>
            JOBTREAD IS GREAT.<br/>
            <span style={{ color: 'var(--accent)' }}>THIS MAKES IT AWESOME.</span>
          </h1>

          <p style={{ fontSize: 19, color: 'var(--fg-muted)', lineHeight: 1.55, marginBottom: 32, maxWidth: 560 }}>
            The all-in-one browser extension toolkit that transforms JobTread into a powerhouse. Dark mode, rich text formatting, message templates, job switcher filtering, and more.
          </p>

          <div style={{ display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap' }}>
            <a className="jt-btn jt-btn-primary" style={{ fontSize: 15, padding: '14px 22px' }}>
              <i className="ph ph-download-simple"/> Install Free Extension
            </a>
            <a className="jt-btn jt-btn-ghost" style={{ fontSize: 15, padding: '14px 22px' }}>
              See Features
            </a>
          </div>

          <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', fontSize: 13, color: 'var(--fg-subtle)' }}>
            <span><span className="jt-dot" style={{ marginRight: 8 }}/>Free forever plan</span>
            <span><span className="jt-dot" style={{ marginRight: 8 }}/>No signup to start</span>
            <span><span className="jt-dot" style={{ marginRight: 8 }}/>400+ contractors</span>
          </div>
        </div>

        {/* Popup mockup */}
        <HeroPopupMock/>
      </div>
    </section>
  );
}

function HeroPopupMock() {
  return (
    <div style={{
      background: 'var(--jt-coal-050)',
      border: '1px solid var(--jt-coal-200)',
      borderRadius: 14,
      width: '100%', maxWidth: 420,
      marginLeft: 'auto',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-xl)',
      color: '#e8e3d7',
      fontFamily: 'var(--ff-body)',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 18px', borderBottom: '1px solid #2a2a2a' }}>
        <div className="jt-gear" data-theme="dark" style={{ width: 26, height: 26, backgroundImage: `url(${(window.__resources && window.__resources.gearDark) || 'assets/gear-dark.png'})` }}/>
        <span className="jt-display" style={{ fontSize: 16, color: '#fff', letterSpacing: '0.04em' }}>POWER TOOLS</span>
        <span style={{ marginLeft: 'auto', fontSize: 10, fontFamily: 'var(--ff-mono)', color: '#8a8a8a' }}>v4.0.0</span>
        <i className="ph ph-moon" style={{ fontSize: 15, color: 'var(--jt-orange)' }}/>
      </div>

      {/* Tab nav */}
      <div style={{ display: 'flex', borderBottom: '1px solid #2a2a2a' }}>
        {[
          ['ph-lightning', 'Features', true],
          ['ph-palette', 'Theme', false],
          ['ph-plugs-connected', 'API', false],
          ['ph-key', 'License', false],
        ].map(([i, l, a]) => (
          <div key={l} style={{
            flex: 1, padding: '10px 6px', textAlign: 'center',
            fontSize: 11, fontWeight: 600,
            color: a ? 'var(--jt-orange)' : '#8a8a8a',
            borderBottom: a ? '2px solid var(--jt-orange)' : '2px solid transparent',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
          }}>
            <i className={`ph ${i}`} style={{ fontSize: 14 }}/>
            {l}
          </div>
        ))}
      </div>

      {/* Category: Schedule */}
      <PopupCategory icon="ph-calendar-blank" title="Schedule & Calendar" count={5}>
        <PopupFeature name="Auto Collapse Completed" desc="Collapse 100% complete groups" active/>
        <PopupFeature name="Schedule Task Checkboxes" badge="pro" desc="Mark task cards complete" active/>
      </PopupCategory>
      <PopupCategory icon="ph-lightning" title="Productivity Tools" count={8}>
        <PopupFeature name="Text Formatter" desc="Rich text toolbar for budgets & tasks" active/>
        <PopupFeature name="Quick Notes" badge="essential" desc="Persistent notepad (Q+N)"/>
      </PopupCategory>
      <PopupCategory icon="ph-palette" title="Appearance" count={4}>
        <PopupFeature name="Dark Mode" desc="Dark theme for JobTread" active/>
      </PopupCategory>
    </div>
  );
}

function PopupCategory({ icon, title, count, children }) {
  return (
    <div style={{ borderBottom: '1px solid #1a1a1a' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 18px', background: '#0f0f0f' }}>
        <div style={{ width: 22, height: 22, borderRadius: 6, background: '#1a1a1a', display: 'grid', placeItems: 'center', color: 'var(--jt-orange)' }}>
          <i className={`ph ${icon}`} style={{ fontSize: 12 }}/>
        </div>
        <span style={{ fontSize: 12, fontWeight: 700, color: '#d5d5d5', letterSpacing: '0.02em' }}>{title}</span>
        <span style={{ fontSize: 10, color: '#606060', marginLeft: 4 }}>{count}</span>
        <span style={{ marginLeft: 'auto', fontSize: 10, color: '#606060' }}>▼</span>
      </div>
      {children}
    </div>
  );
}

function PopupFeature({ name, desc, badge, active }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 18px' }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: '#e8e3d7', display: 'flex', alignItems: 'center', gap: 6 }}>
          {name}
          {badge && (
            <span style={{
              fontSize: 8, padding: '1px 5px', borderRadius: 8, fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase',
              background: badge === 'pro' ? 'var(--jt-orange-dim)' : 'oklch(32% 0.10 170 / 0.4)',
              color: badge === 'pro' ? 'var(--jt-orange-hot)' : '#4dd4a8',
            }}>{badge}</span>
          )}
        </div>
        <div style={{ fontSize: 10, color: '#8a8a8a', marginTop: 1 }}>{desc}</div>
      </div>
      <div style={{
        width: 28, height: 16, borderRadius: 10,
        background: active ? 'var(--jt-orange)' : '#2a2a2a',
        position: 'relative', flexShrink: 0,
      }}>
        <div style={{
          position: 'absolute', top: 2, left: active ? 14 : 2,
          width: 12, height: 12, borderRadius: '50%',
          background: '#fff', transition: 'left 0.2s',
        }}/>
      </div>
    </div>
  );
}

window.NavV5 = NavV5;
window.HeroV5 = HeroV5;
