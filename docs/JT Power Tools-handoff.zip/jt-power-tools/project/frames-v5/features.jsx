/* global React */
// v5 — Features grid. All 20 features in 4 categories.

const FEATURE_SECTIONS = [
  {
    label: 'High-Impact Workflow Tools',
    sub: 'Features that directly change how you interact with data to complete tasks faster.',
    items: [
      ['ph-check-square', 'Schedule & Task Checkboxes', 'Checkboxes on task cards in month schedule view and Action Items for instant task completion. Mark complete or incomplete directly from the calendar without opening details.', 'pro'],
      ['ph-git-diff', 'Budget Changelog', 'Compare budget backups and see exactly what changed between versions. Track additions, deletions, and modifications with a detailed report. Perfect for change order documentation.', 'power'],
      ['ph-funnel', 'Job Switcher Filter', 'Filter jobs by custom field values in the Job Switcher. API-powered dropdown auto-populates with your custom field values. Find jobs by PM, status, or any custom field.', 'power'],
      ['ph-funnel-simple', 'Availability Filter', 'Filter assignees by role, department, or category in the Schedule Availability view. Save custom filter views for instant recall. Hierarchical toggles with count badges.', 'pro'],
    ],
  },
  {
    label: 'Content & Editing Efficiency',
    sub: 'Speed up creation and review of project documentation.',
    items: [
      ['ph-text-aa', 'Text Formatter', 'Rich text formatting toolbar for budget descriptions and notes. Bold, italic, headings, lists, tables, colors, and more. Full keyboard shortcuts support (Ctrl/Cmd + B/I/U).'],
      ['ph-eye', 'Preview Mode', 'Live preview of formatted text with a floating preview panel. See how your markdown renders in real-time as you type. Works on budget descriptions and daily log fields.', 'pro'],
      ['ph-file-pdf', 'PDF Markup Tools', 'Enhanced PDF annotation with professional stamps and improved eraser. Approval stamps, date stamps, and architecture symbols for construction plan markup.', 'essential'],
      ['ph-hash', 'Character Counter & Templates', 'Real-time character count for messages plus reusable templates. Create and save message templates for quick insertion with one click. Syncs across devices via Chrome storage.'],
    ],
  },
  {
    label: 'Visual Data Organization',
    sub: 'Process information on screen more quickly with smarter layouts.',
    items: [
      ['ph-tree-structure', 'Budget Hierarchy Shading', 'Progressive visual shading for nested budget groups up to 5 levels deep. Instantly identify group hierarchy and relationships at a glance. Line items auto-inherit parent shading.'],
      ['ph-calculator', 'Auto Sum', 'Select budget line items to see live totals for Extended Cost, Extended Price, and Profit with margin. Handles virtual scrolling, skips parent groups, adapts to dark mode.'],
      ['ph-folder-simple', 'Auto Collapse Completed', 'Automatically collapses schedule groups that are 100% complete on page load. Reduces clutter while keeping active items visible. Groups expand normally when clicked.'],
      ['ph-kanban', 'Kanban Filtering', 'Automatically hides empty columns in Kanban/grouped views. Reduces visual clutter and horizontal scrolling. Updates in real-time as items are moved between columns.'],
      ['ph-sort-descending', 'Reverse Thread Order', 'Newest messages appear at the top of threads with the reply form above the conversation. Works across all message locations — jobs, documents, daily logs, and sidebars.', 'essential'],
    ],
  },
  {
    label: 'Interface & Legibility',
    sub: 'Comfort and accessibility improvements for long work sessions.',
    items: [
      ['ph-push-pin', 'Freeze Header', 'Keeps job info and navigation tabs visible while scrolling. Sticky header stays at top for easy access to job details without scrolling back up.', 'essential'],
      ['ph-sun-dim', 'Contrast Fix', 'Automatically adjusts text colors for better readability in schedule views using WCAG contrast formulas. Highlights the current date. Real-time updates as content changes.'],
      ['ph-moon', 'Dark Mode', 'Beautiful dark theme for JobTread that reduces eye strain during long work sessions. Customized specifically for construction management workflows. Syncs across devices.'],
      ['ph-chart-line-up', 'Fat Gantt', 'Makes Gantt dependency lines thicker and easier to click. Lines increased from 1.5px to 3.5px with rounded corners. Selected lines are highlighted for clear visibility.'],
      ['ph-palette', 'Custom Theme', 'Personalize JobTread with your own color palette. Choose primary, background, and text colors. Save up to 3 custom themes for quick switching. Preserves task type colors.', 'pro'],
      ['ph-notepad', 'Quick Notes', 'Persistent notepad accessible from any JobTread page. Press Q+N or click the header icon. Create, edit, search, and organize multiple notes with rich formatting.', 'essential'],
    ],
  },
];

function FeaturesV5() {
  return (
    <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--rule)' }}>
      <div style={{ textAlign: 'center', marginBottom: 64, maxWidth: 780, margin: '0 auto 64px' }}>
        <div className="jt-eyebrow" style={{ marginBottom: 12 }}>Features</div>
        <h2 className="jt-display" style={{ fontSize: 84, color: 'var(--fg-strong)', marginBottom: 18 }}>
          THE MISSING PIECE OF YOUR<br/>
          <span style={{ color: 'var(--accent)' }}>JOBTREAD WORKFLOW</span>
        </h2>
        <p style={{ fontSize: 18, color: 'var(--fg-muted)', lineHeight: 1.55 }}>
          JT Power Tools adds the essential features you've always wished for, designed specifically for the speed of the construction industry.
        </p>
      </div>

      {FEATURE_SECTIONS.map((sec, si) => (
        <div key={sec.label} style={{ marginBottom: si < FEATURE_SECTIONS.length - 1 ? 72 : 0 }}>
          <div style={{
            display: 'flex', alignItems: 'baseline', gap: 18,
            padding: '16px 0 18px',
            borderBottom: '1px solid var(--rule)',
            marginBottom: 24,
          }}>
            <span style={{
              fontFamily: 'var(--ff-mono)', fontSize: 12, fontWeight: 600,
              color: 'var(--accent)', letterSpacing: '0.05em',
            }}>0{si + 1}</span>
            <h3 className="jt-display" style={{ fontSize: 32, color: 'var(--fg-strong)' }}>{sec.label}</h3>
            <span style={{ fontSize: 14, color: 'var(--fg-muted)', fontStyle: 'italic', marginLeft: 'auto', maxWidth: 460, textAlign: 'right' }}>{sec.sub}</span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            {sec.items.map(([icon, name, desc, tier]) => (
              <FeatureCard key={name} icon={icon} name={name} desc={desc} tier={tier}/>
            ))}
          </div>
        </div>
      ))}
    </section>
  );
}

function FeatureCard({ icon, name, desc, tier }) {
  return (
    <div style={{
      background: 'var(--bg-surface)',
      border: '1px solid var(--rule)',
      borderRadius: 'var(--r-lg)',
      padding: '22px 20px 24px',
      position: 'relative',
      display: 'flex', flexDirection: 'column',
      transition: 'transform 0.2s ease, border-color 0.2s ease',
    }}>
      {tier && (
        <span className={`jt-badge jt-badge-${tier}`} style={{ position: 'absolute', top: 14, right: 14 }}>
          {tier === 'power' ? 'Power User' : tier}
        </span>
      )}
      <div style={{
        width: 40, height: 40, borderRadius: 8,
        background: 'var(--bg-raised)',
        border: '1px solid var(--rule)',
        display: 'grid', placeItems: 'center',
        color: 'var(--accent-ink)',
        marginBottom: 14,
      }}>
        <i className={`ph ${icon}`} style={{ fontSize: 22 }}/>
      </div>
      <h4 className="jt-display-upright" style={{ fontSize: 16, color: 'var(--fg-strong)', marginBottom: 8, letterSpacing: '0.02em' }}>{name}</h4>
      <p style={{ fontSize: 13, color: 'var(--fg-muted)', lineHeight: 1.5 }}>{desc}</p>
    </div>
  );
}

window.FeaturesV5 = FeaturesV5;
