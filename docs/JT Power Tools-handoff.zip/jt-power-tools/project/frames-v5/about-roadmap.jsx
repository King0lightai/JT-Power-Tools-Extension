/* global React */
// v5 — About & Roadmap pages, rebuilt on the real logo tokens.

function AboutV5() {
  return (
    <div className="jt-frame" style={{ width: 1440, minHeight: 1800, background: 'var(--bg)' }}>
      <NavV5 theme="light" onToggleTheme={()=>{}} active="About"/>

      {/* Hero */}
      <section style={{ padding: '112px 48px 80px', borderBottom: '1px solid var(--rule)', position: 'relative', overflow: 'hidden' }}>
        <div className="jt-gear" style={{
          position: 'absolute', top: -160, right: -180,
          width: 640, height: 640, opacity: 0.05, transform: 'rotate(-14deg)',
        }}/>
        <div className="jt-eyebrow" style={{ marginBottom: 18 }}>The story</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 64, alignItems: 'end' }}>
          <h1 className="jt-display" style={{ fontSize: 148, color: 'var(--fg-strong)', lineHeight: 0.86 }}>
            BUILT IN THE<br/>
            <span style={{ color: 'var(--accent)' }}>FIELD,</span><br/>
            NOT A BOARDROOM.
          </h1>
          <p style={{ fontSize: 18, color: 'var(--fg-muted)', lineHeight: 1.55, paddingBottom: 16, maxWidth: 420 }}>
            The story of a construction IT lead who stopped waiting for features — and built the toolkit the rest of us have been asking for.
          </p>
        </div>
      </section>

      {/* Story block */}
      <section style={{ padding: '88px 48px', borderBottom: '1px solid var(--rule)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 72, alignItems: 'start' }}>
          <div>
            <div style={{
              aspectRatio: '3/4',
              background: 'var(--bg-raised)',
              border: '1px solid var(--rule)',
              borderRadius: 6,
              display: 'grid', placeItems: 'center',
              boxShadow: 'var(--shadow-md)',
              position: 'relative',
            }}>
              <div style={{ textAlign: 'center' }}>
                <i className="ph ph-user-circle" style={{ fontSize: 72, color: 'var(--fg-subtle)' }}/>
                <div style={{ fontSize: 12, color: 'var(--fg-subtle)', marginTop: 8, fontFamily: 'var(--ff-mono)' }}>PORTRAIT · ZEE</div>
              </div>
              {/* Safety-tape corner */}
              <div className="jt-safety-tape" style={{
                position: 'absolute', top: 0, left: 0,
                width: 80, height: 10,
              }}/>
            </div>
            <div style={{ marginTop: 22 }}>
              <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--fg-strong)' }}>Zee</div>
              <div style={{ fontSize: 13, color: 'var(--fg-subtle)', marginTop: 4 }}>
                IT Director & Builder · Oklahoma
              </div>
              <div className="jt-serif" style={{
                fontSize: 22, color: 'var(--accent-ink)',
                marginTop: 18, lineHeight: 1.2,
              }}>
                "just fix the damn thing"
              </div>
            </div>
          </div>

          <div>
            <h2 className="jt-display" style={{ fontSize: 60, color: 'var(--fg-strong)', marginBottom: 32, lineHeight: 1 }}>
              IT STARTED WITH A <span style={{ color: 'var(--accent)' }}>CHECKBOX.</span>
            </h2>
            <p style={{ fontSize: 18, color: 'var(--fg-muted)', lineHeight: 1.75, marginBottom: 22 }}>
              A dozen contractors on the JobTread forum asking for the same thing:{' '}
              <em className="jt-serif" style={{ fontSize: 20, color: 'var(--fg-strong)' }}>
                "can we please just check off tasks on the schedule?"
              </em>{' '}
              Years went by. Nothing shipped.
            </p>
            <p style={{ fontSize: 18, color: 'var(--fg-muted)', lineHeight: 1.75, marginBottom: 22 }}>
              So one weekend, I wrote a Chrome extension. Twenty lines of JavaScript.
              It worked. Then the next pain point. Then the next. Then 400 contractors,
              20 features, and an MCP server that lets Claude read your jobs.
            </p>
            <p style={{ fontSize: 18, color: 'var(--fg-muted)', lineHeight: 1.75, marginBottom: 44 }}>
              JT Power Tools is what happens when a contractor's IT lead stops asking
              nicely and starts shipping.
            </p>

            <div className="jt-eyebrow-muted" style={{ marginBottom: 16 }}>Pain points solved</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
              {[
                ['ph-check-square', 'Click-to-complete'],
                ['ph-text-aa', 'Rich formatting'],
                ['ph-moon', 'Eye strain'],
                ['ph-broom', 'Kanban clutter'],
              ].map(([i, l]) => (
                <div key={l} className="jt-card" style={{ padding: 20, textAlign: 'center' }}>
                  <i className={`ph ${i}`} style={{ fontSize: 28, color: 'var(--accent-ink)', marginBottom: 10 }}/>
                  <div style={{ fontSize: 13, color: 'var(--fg-strong)', fontWeight: 600 }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats strip */}
      <section style={{ padding: '88px 48px', borderBottom: '1px solid var(--rule)', background: 'var(--bg-surface)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
          {[
            ['400+', 'Contractors using the tools'],
            ['20', 'Power tools in the box'],
            ['3 hrs', 'Saved per user per week'],
            ['4.9★', 'Chrome Web Store average'],
          ].map(([n, l], i) => (
            <div key={l} style={{
              textAlign: 'center',
              borderLeft: i === 0 ? 'none' : '1px solid var(--rule)',
              padding: '0 12px',
            }}>
              <div className="jt-display" style={{ fontSize: 100, color: 'var(--accent)', lineHeight: 0.9, marginBottom: 12 }}>{n}</div>
              <div style={{ fontSize: 13, color: 'var(--fg-muted)', letterSpacing: '0.02em' }}>{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: '96px 48px', textAlign: 'center' }}>
        <h2 className="jt-serif" style={{ fontSize: 68, color: 'var(--fg-strong)', marginBottom: 18, lineHeight: 1.05 }}>
          Got a JobTread gripe?<br/>Let's fix it.
        </h2>
        <p style={{ fontSize: 16, color: 'var(--fg-muted)', marginBottom: 32 }}>
          Every shipped tool started as someone complaining on Discord.
        </p>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <a className="jt-btn jt-btn-primary" style={{ fontSize: 15, padding: '16px 24px' }}>
            <i className="ph ph-discord-logo" style={{ fontSize: 18 }}/> Join our Discord
          </a>
          <a className="jt-btn jt-btn-ghost" style={{ fontSize: 15, padding: '16px 24px' }}>
            <i className="ph ph-envelope-simple" style={{ fontSize: 18 }}/> Email the team
          </a>
        </div>
      </section>

      <FooterV5/>
    </div>
  );
}

function RoadmapV5() {
  const cols = [
    {
      title: 'Shipped', sub: 'Already in the toolbox',
      tone: { dot: 'var(--jt-green)', label: '#006b52', bg: 'oklch(95% 0.04 170)' },
      items: [
        ['MCP Server for AI', 'Mar 2026', 'Power User'],
        ['Job Switcher Filter', 'Feb 2026', 'Power User'],
        ['Budget Changelog', 'Jan 2026', 'Power User'],
        ['PDF Markup Tools', 'Dec 2025', 'Essential'],
        ['Schedule Task Checkboxes', 'Nov 2025', 'Pro'],
        ['Custom Theme Colors', 'Oct 2025', 'Pro'],
      ],
    },
    {
      title: 'Building now', sub: 'Current sprint',
      tone: { dot: 'var(--accent)', label: 'var(--accent-ink)', bg: 'var(--accent-wash)' },
      items: [
        ['Availability Saved Views', 'Next week', 'Pro'],
        ['Faster AI responses', 'This month', 'Power User'],
        ['Mobile popup redesign', 'This month', 'Free'],
      ],
    },
    {
      title: 'Up next', sub: 'Planned for Q3',
      tone: { dot: 'var(--jt-yellow)', label: '#8a6500', bg: 'oklch(96% 0.06 85)' },
      items: [
        ['Document ingestion for AI', 'Summer', 'Power User'],
        ['Semantic job search', 'Summer', 'Power User'],
        ['Budget snapshots diff', 'Summer', 'Power User'],
        ['Knowledge base', 'Summer', 'Essential'],
      ],
    },
    {
      title: 'Exploring', sub: 'Thinking about it',
      tone: { dot: 'var(--fg-subtle)', label: 'var(--fg-muted)', bg: 'var(--bg-raised)' },
      items: [
        ['Mobile companion app', 'Maybe', null],
        ['Voice quick notes', 'Maybe', null],
        ['Public API', 'Maybe', null],
        ['Offline mode', 'Maybe', null],
      ],
    },
  ];

  const tierColor = {
    Free:        'var(--fg-muted)',
    Essential:   '#00a87a',
    Pro:         'var(--accent-ink)',
    'Power User':'#C850FF',
  };

  return (
    <div className="jt-frame" style={{ width: 1440, minHeight: 1700, background: 'var(--bg)' }}>
      <NavV5 theme="light" onToggleTheme={()=>{}} active="Roadmap"/>

      {/* Hero */}
      <section style={{ padding: '112px 48px 72px', borderBottom: '1px solid var(--rule)', position: 'relative', overflow: 'hidden' }}>
        <div className="jt-eyebrow" style={{ marginBottom: 18 }}>Roadmap · Updated weekly</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 64, alignItems: 'end' }}>
          <h1 className="jt-display" style={{ fontSize: 148, color: 'var(--fg-strong)', lineHeight: 0.86 }}>
            WHAT'S BUILT.<br/>WHAT'S <span style={{ color: 'var(--accent)' }}>NEXT.</span>
          </h1>
          <p style={{ fontSize: 17, color: 'var(--fg-muted)', lineHeight: 1.55, paddingBottom: 20 }}>
            Public and honest. Vote on our Discord — the features with the most 👍 jump the queue.
          </p>
        </div>
      </section>

      {/* Kanban */}
      <section style={{ padding: '72px 48px', borderBottom: '1px solid var(--rule)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18 }}>
          {cols.map(col => (
            <div key={col.title} className="jt-card" style={{ overflow: 'hidden', padding: 0 }}>
              <div style={{ padding: '18px 20px', borderBottom: '1px solid var(--rule)', background: col.tone.bg }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: col.tone.dot, display: 'inline-block' }}/>
                  <span className="jt-display-upright" style={{ fontSize: 16, color: col.tone.label, letterSpacing: '0.05em' }}>
                    {col.title.toUpperCase()}
                  </span>
                  <span style={{ marginLeft: 'auto', fontFamily: 'var(--ff-mono)', fontSize: 11, color: col.tone.label, fontWeight: 700 }}>
                    {String(col.items.length).padStart(2, '0')}
                  </span>
                </div>
                <div style={{ fontSize: 12, color: col.tone.label, opacity: 0.75 }}>{col.sub}</div>
              </div>
              <div style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 10, background: 'var(--bg-raised)' }}>
                {col.items.map(([t, when, tier]) => (
                  <div key={t} className="jt-card" style={{ padding: '14px 16px' }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--fg-strong)', marginBottom: 6, lineHeight: 1.3 }}>{t}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontSize: 11, color: 'var(--fg-subtle)', fontFamily: 'var(--ff-mono)' }}>{when}</span>
                      {tier && (
                        <span style={{
                          fontSize: 9, fontWeight: 800, letterSpacing: '0.1em',
                          textTransform: 'uppercase', padding: '2px 6px', borderRadius: 4,
                          border: `1px solid ${tierColor[tier]}`,
                          color: tierColor[tier],
                          marginLeft: 'auto',
                        }}>{tier}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Request CTA */}
      <section style={{ padding: '96px 48px', textAlign: 'center' }}>
        <h2 className="jt-serif" style={{ fontSize: 64, color: 'var(--fg-strong)', marginBottom: 18, lineHeight: 1.05 }}>
          Want something built?<br/>Ask for it.
        </h2>
        <p style={{ fontSize: 16, color: 'var(--fg-muted)', maxWidth: 560, margin: '0 auto 32px' }}>
          Every shipped tool started as a suggestion. Your workflow problem is probably someone else's too.
        </p>
        <a className="jt-btn jt-btn-primary" style={{ fontSize: 15, padding: '16px 26px' }}>
          <i className="ph ph-discord-logo" style={{ fontSize: 18 }}/> Suggest on Discord
        </a>
      </section>

      <FooterV5/>
    </div>
  );
}

window.AboutV5 = AboutV5;
window.RoadmapV5 = RoadmapV5;
