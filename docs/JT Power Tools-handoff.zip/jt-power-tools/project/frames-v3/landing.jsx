/* global React */
// Landing v3 — warm paper. Zee's voice. Texture. Authorship.

function LandingFrameV3() {
  return (
    <div className="jt-frame-paper jt-grain-paper" style={{ width: 1280, height: 3800, overflow: 'hidden', position: 'relative' }}>
      <div className="jt-tape-paper" style={{ height: 8 }}/>

      {/* Nav */}
      <nav style={{ display: 'flex', alignItems: 'center', padding: '18px 48px', borderBottom: '1px solid var(--paper-rule)', background: 'rgba(250, 247, 242, 0.92)', backdropFilter: 'blur(10px)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, background: 'var(--paper-ink)', display: 'grid', placeItems: 'center', borderRadius: 4 }}>
            <span className="jt-display" style={{ fontSize: 17, color: 'var(--flame)' }}>JT</span>
          </div>
          <span className="jt-display" style={{ fontSize: 18, letterSpacing: '0.05em', color: 'var(--paper-ink)' }}>POWER TOOLS</span>
        </div>
        <div style={{ display: 'flex', gap: 28, marginLeft: 64 }}>
          {['The tools', 'Pricing', 'Roadmap', 'About', 'Docs'].map(l => (
            <a key={l} style={{ fontSize: 14, color: 'var(--paper-ink-2)', cursor: 'pointer', fontWeight: 500 }}>{l}</a>
          ))}
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 10 }}>
          <button style={{ padding: '10px 16px', background: 'transparent', border: '1px solid var(--paper-rule)', color: 'var(--paper-ink)', fontSize: 13, cursor: 'pointer', fontWeight: 600, borderRadius: 5 }}>Sign in</button>
          <button style={{ padding: '10px 18px', background: 'var(--paper-ink)', border: 'none', color: 'var(--paper-000)', fontSize: 13, cursor: 'pointer', fontWeight: 700, borderRadius: 5 }}>Install free →</button>
        </div>
      </nav>

      {/* HERO */}
      <section style={{ padding: '90px 48px 40px', borderBottom: '1px solid var(--paper-rule)', position: 'relative' }}>
        {/* Margin annotation — hand-written by Zee */}
        <div style={{ position: 'absolute', top: 140, right: 72, transform: 'rotate(-6deg)', width: 180, textAlign: 'center' }}>
          <div className="jt-hand" style={{ color: 'var(--ink-pen)', fontSize: 28, lineHeight: 1.1, marginBottom: 6 }}>
            the one feature<br/>JobTread won't ship
          </div>
          <svg width="60" height="40" viewBox="0 0 60 40" style={{ margin: '0 auto', transform: 'rotate(20deg)' }}>
            <path d="M5,5 Q20,25 50,30" stroke="var(--ink-pen)" strokeWidth="2" fill="none" strokeLinecap="round"/>
            <path d="M45,25 L50,30 L44,34" stroke="var(--ink-pen)" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 0.9fr', gap: 56, alignItems: 'end' }}>
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px', background: 'var(--flame-wash)', border: '1px solid var(--flame-ink)', borderRadius: 20, marginBottom: 28 }}>
              <i className="ph ph-hammer" style={{ color: 'var(--flame-ink)', fontSize: 14 }}/>
              <span style={{ fontSize: 12, color: 'var(--flame-ink)', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Built by a contractor, for contractors</span>
            </div>
            <h1 className="jt-display" style={{ fontSize: 168, color: 'var(--paper-ink)', lineHeight: 0.86, marginBottom: 28 }}>
              23 HACKS<br/>
              THAT MAKE<br/>
              JOBTREAD<br/>
              <span className="jt-serif" style={{ fontSize: 180, fontStyle: 'italic', color: 'var(--flame)' }}>awesome.</span>
            </h1>
          </div>
          <div style={{ paddingBottom: 32 }}>
            <p style={{ fontSize: 20, color: 'var(--paper-ink-2)', lineHeight: 1.55, marginBottom: 28, maxWidth: 400 }}>
              Task checkboxes. Rich text. Dark mode. An AI helper that reads your jobs. And all the other little things you've wished JobTread had. <strong style={{ color: 'var(--paper-ink)' }}>One Chrome extension.</strong>
            </p>
            <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
              <button style={{ padding: '16px 24px', background: 'var(--flame)', color: 'var(--paper-000)', border: 'none', borderRadius: 6, fontSize: 14, fontWeight: 700, cursor: 'pointer', boxShadow: '0 3px 0 rgba(29, 26, 21, 0.2)' }}>
                <i className="ph ph-download-simple" style={{ marginRight: 8 }}/>Install free
              </button>
              <button style={{ padding: '16px 24px', background: 'transparent', color: 'var(--paper-ink)', border: '1px solid var(--paper-rule)', borderRadius: 6, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
                Watch 90-sec demo
              </button>
            </div>
            <div style={{ display: 'flex', gap: 18, flexWrap: 'wrap' }}>
              <span style={{ fontSize: 12, color: 'var(--paper-ink-3)' }}><span className="jt-dot paper-green" style={{ marginRight: 6 }}/>Free forever plan</span>
              <span style={{ fontSize: 12, color: 'var(--paper-ink-3)' }}><span className="jt-dot paper-green" style={{ marginRight: 6 }}/>No credit card</span>
              <span style={{ fontSize: 12, color: 'var(--paper-ink-3)' }}><span className="jt-dot paper-green" style={{ marginRight: 6 }}/>2,400+ contractors</span>
            </div>
          </div>
        </div>

        {/* Screenshot — framed like a photo print on paper */}
        <div style={{ marginTop: 64, background: 'var(--paper-ink)', padding: 14, borderRadius: 4, boxShadow: '0 20px 60px rgba(29, 26, 21, 0.15), 0 2px 4px rgba(29, 26, 21, 0.1)' }}>
          <div style={{ display: 'flex', gap: 6, padding: '6px 4px 10px', alignItems: 'center' }}>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#FF5F57' }}/>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#FDBC2C' }}/>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#28C940' }}/>
            <span style={{ marginLeft: 12, fontSize: 12, color: '#a89f8b' }}>app.jobtread.com/schedule — with Power Tools on</span>
          </div>
          <div style={{ aspectRatio: '16/9', background: '#1a1612', borderRadius: 2, display: 'grid', placeItems: 'center', textAlign: 'center' }}>
            <div>
              <i className="ph ph-image" style={{ fontSize: 44, color: '#5a5145', marginBottom: 12 }}/>
              <div style={{ fontSize: 14, color: '#a89f8b' }}>Screenshot of JobTread schedule with checkboxes enabled</div>
              <div style={{ fontSize: 12, color: '#7a7060', marginTop: 4 }}>(Real product shot goes here)</div>
            </div>
          </div>
        </div>
      </section>

      {/* THE PAIN — before/after — a JT trope proof */}
      <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--paper-rule)' }}>
        <div style={{ textAlign: 'center', marginBottom: 48 }}>
          <div className="jt-eyebrow-paper" style={{ marginBottom: 12 }}>The receipts</div>
          <h2 className="jt-display" style={{ fontSize: 84, color: 'var(--paper-ink)' }}>
            JOBTREAD <span className="jt-serif" style={{ fontStyle: 'italic', color: 'var(--paper-ink-3)' }}>without</span> <span style={{ color: 'var(--paper-ink-4)' }}>vs.</span> <span style={{ color: 'var(--flame)' }}>with.</span>
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          {[
            { label: 'WITHOUT', sub: 'Stock JobTread', tone: 'muted', items: [
              'Open card. Scroll. Find task. Open task. Check. Back. Next.',
              'Plain text everywhere. No bold, no bullets.',
              'White UI only. Your eyes at 8pm.',
              'Ask Claude anything? Copy-paste into another tab.',
            ]},
            { label: 'WITH POWER TOOLS', sub: '30 seconds to install', tone: 'flame', items: [
              'Click the box on the card. Done.',
              'Rich text. Lists. Colors. Everywhere.',
              'Real dark mode. Eye-friendly after dark.',
              'Claude reads your jobs live. Ask in plain English.',
            ]},
          ].map(col => (
            <div key={col.label} style={{
              background: col.tone === 'flame' ? 'var(--flame-wash)' : 'var(--paper-100)',
              border: `1px solid ${col.tone === 'flame' ? 'var(--flame)' : 'var(--paper-rule)'}`,
              borderRadius: 12, padding: 36, position: 'relative',
            }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '0.12em', color: col.tone === 'flame' ? 'var(--flame-ink)' : 'var(--paper-ink-3)', marginBottom: 4 }}>{col.label}</div>
              <div style={{ fontSize: 13, color: 'var(--paper-ink-2)', marginBottom: 24 }}>{col.sub}</div>
              {col.items.map((t, i) => (
                <div key={i} style={{ display: 'flex', gap: 12, padding: '14px 0', borderTop: i === 0 ? 'none' : '1px solid rgba(29, 26, 21, 0.08)', alignItems: 'flex-start' }}>
                  <i className={`ph ${col.tone === 'flame' ? 'ph-check-circle' : 'ph-x-circle'}`} style={{ color: col.tone === 'flame' ? 'var(--flame)' : 'var(--paper-ink-4)', fontSize: 20, flexShrink: 0, marginTop: 2 }}/>
                  <span style={{ fontSize: 16, color: col.tone === 'flame' ? 'var(--paper-ink)' : 'var(--paper-ink-2)', lineHeight: 1.5 }}>{t}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* TOOLBOX */}
      <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--paper-rule)' }}>
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <div className="jt-eyebrow-paper" style={{ marginBottom: 12 }}>The Toolbox</div>
          <h2 className="jt-display" style={{ fontSize: 84, color: 'var(--paper-ink)' }}>EVERY HACK <span style={{ color: 'var(--flame)' }}>YOU'VE WANTED.</span></h2>
          <p style={{ fontSize: 17, color: 'var(--paper-ink-2)', maxWidth: 600, margin: '18px auto 0' }}>Each one fixes something you've cursed out loud.</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18 }}>
          {[
            ['ph-check-square', 'Task checkboxes', 'Check off schedule cards without opening them. Save 3 clicks per task.', 'Most loved'],
            ['ph-text-aa', 'Rich text everywhere', 'Bold, italic, lists, colors in every description box.'],
            ['ph-moon', 'Real dark mode', 'Actually readable. Not an afterthought tint.'],
            ['ph-robot', 'AI helper', 'Ask Claude about your jobs. Get answers from your data.', 'New'],
            ['ph-note-pencil', 'Quick notes', 'Persistent notepad on any page. Q+N opens it.'],
            ['ph-clipboard-text', 'Message templates', 'Save signatures and common replies. Paste in one click.'],
            ['ph-calculator', 'Auto-sum totals', 'Highlight rows — see cost, price, profit live.'],
            ['ph-file-pdf', 'PDF markup tools', 'Stamps, eraser, and annotations on PDFs.'],
            ['ph-columns', 'Frozen tabs', 'Keep job tabs visible while scrolling long pages.'],
          ].map(([i, t, d, tag]) => (
            <div key={t} style={{
              background: 'var(--paper-050)', border: '1px solid var(--paper-rule)', borderRadius: 10,
              padding: 28, position: 'relative', overflow: 'hidden',
            }}>
              {tag && (
                <div style={{
                  position: 'absolute', top: 14, right: 14,
                  fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase',
                  padding: '4px 8px', borderRadius: 10,
                  background: 'var(--flame)', color: 'var(--paper-000)',
                }}>{tag}</div>
              )}
              <div style={{
                width: 56, height: 56, borderRadius: 10, background: 'var(--paper-100)',
                border: '1px solid var(--paper-rule)',
                display: 'grid', placeItems: 'center', color: 'var(--flame-ink)', marginBottom: 18,
              }}>
                <i className={`ph ${i}`} style={{ fontSize: 28 }}/>
              </div>
              <h3 style={{ fontSize: 20, fontWeight: 700, color: 'var(--paper-ink)', marginBottom: 6, letterSpacing: '-0.01em' }}>{t}</h3>
              <p style={{ fontSize: 14, color: 'var(--paper-ink-2)', lineHeight: 1.55 }}>{d}</p>
            </div>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: 40 }}>
          <button style={{ padding: '14px 24px', background: 'transparent', color: 'var(--paper-ink)', border: '1px solid var(--paper-rule)', borderRadius: 6, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
            See all 23 tools →
          </button>
        </div>
      </section>

      {/* TESTIMONIAL — framed like a pinned note */}
      <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--paper-rule)', position: 'relative' }}>
        <div style={{ maxWidth: 960, margin: '0 auto', textAlign: 'center', position: 'relative' }}>
          <i className="ph ph-quotes" style={{ fontSize: 40, color: 'var(--flame)', marginBottom: 20 }}/>
          <p className="jt-serif" style={{ fontSize: 52, color: 'var(--paper-ink)', lineHeight: 1.15, fontStyle: 'italic' }}>
            "I get three hours back a week. The task checkboxes alone paid for the whole year."
          </p>
          <div style={{ marginTop: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14 }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'var(--paper-100)', border: '1px solid var(--paper-rule)' }}/>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--paper-ink)' }}>David B.</div>
              <div style={{ fontSize: 13, color: 'var(--paper-ink-3)' }}>Operations Lead · Tulsa, OK</div>
            </div>
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--paper-rule)' }}>
        <div style={{ textAlign: 'center', marginBottom: 48 }}>
          <div className="jt-eyebrow-paper" style={{ marginBottom: 12 }}>Pricing</div>
          <h2 className="jt-display" style={{ fontSize: 84, color: 'var(--paper-ink)' }}>THREE TIERS. <span style={{ color: 'var(--flame)' }}>NO CATCH.</span></h2>
          <p style={{ fontSize: 17, color: 'var(--paper-ink-2)', maxWidth: 600, margin: '18px auto 0' }}>Start free. Upgrade when a tool pays for itself.</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, maxWidth: 1100, margin: '0 auto' }}>
          {[
            { name: 'Essential', price: '$0', per: 'forever', desc: 'The basics. No account needed.', feats: ['Dark mode', 'Rich text', 'Auto-sum totals', 'Schedule basics'], cta: 'Install free', featured: false },
            { name: 'Pro', price: '$9', per: 'per month', desc: 'For working contractors.', feats: ['Everything in Essential', 'Task checkboxes', 'Quick notes', 'Message templates', 'Custom theme colors', 'Availability filter'], cta: 'Start Pro', featured: true, tag: 'Most popular' },
            { name: 'Power User', price: '$24', per: 'per month', desc: 'For teams running the show.', feats: ['Everything in Pro', 'AI helper (Claude, GPT)', 'Team management', 'Budget changelog', 'Priority support'], cta: 'Go Power', featured: false },
          ].map(p => (
            <div key={p.name} style={{
              background: p.featured ? 'var(--paper-ink)' : 'var(--paper-050)',
              color: p.featured ? 'var(--paper-000)' : 'var(--paper-ink)',
              border: `${p.featured ? 2 : 1}px solid ${p.featured ? 'var(--flame)' : 'var(--paper-rule)'}`,
              borderRadius: 12, padding: '32px 28px', position: 'relative',
            }}>
              {p.tag && <div style={{ position: 'absolute', top: -12, left: 24, padding: '4px 10px', background: 'var(--flame)', color: 'var(--paper-000)', fontSize: 11, fontWeight: 700, borderRadius: 10, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{p.tag}</div>}
              <h3 className="jt-display" style={{ fontSize: 32, marginBottom: 6 }}>{p.name.toUpperCase()}</h3>
              <p style={{ fontSize: 13, color: p.featured ? 'rgba(250,247,242,0.7)' : 'var(--paper-ink-3)', marginBottom: 20 }}>{p.desc}</p>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 24 }}>
                <span className="jt-display" style={{ fontSize: 68 }}>{p.price}</span>
                <span style={{ fontSize: 13, color: p.featured ? 'rgba(250,247,242,0.6)' : 'var(--paper-ink-4)' }}>{p.per}</span>
              </div>
              <button style={{
                width: '100%', padding: '14px', marginBottom: 24,
                background: p.featured ? 'var(--flame)' : 'transparent',
                color: p.featured ? 'var(--paper-000)' : 'var(--paper-ink)',
                border: p.featured ? 'none' : '1px solid var(--paper-rule)',
                borderRadius: 6, fontSize: 14, fontWeight: 700, cursor: 'pointer',
              }}>{p.cta}</button>
              <div style={{ borderTop: p.featured ? '1px solid rgba(250,247,242,0.1)' : '1px solid var(--paper-rule-soft)', paddingTop: 16 }}>
                {p.feats.map(f => (
                  <div key={f} style={{ display: 'flex', gap: 10, padding: '6px 0', fontSize: 14, color: p.featured ? 'rgba(250,247,242,0.9)' : 'var(--paper-ink-2)' }}>
                    <i className="ph ph-check" style={{ color: 'var(--flame)', fontSize: 16, marginTop: 2 }}/>
                    {f}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA — with a signature from Zee */}
      <section style={{ padding: '96px 48px', background: 'var(--paper-ink)', color: 'var(--paper-000)', borderBottom: '1px solid var(--paper-rule)', position: 'relative' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', textAlign: 'center' }}>
          <h2 className="jt-display" style={{ fontSize: 96, marginBottom: 20, lineHeight: 0.9 }}>
            STOP FIGHTING JOBTREAD.<br/>
            <span className="jt-serif" style={{ fontStyle: 'italic', color: 'var(--flame-hot)', fontSize: 104 }}>Start using it.</span>
          </h2>
          <p style={{ fontSize: 18, color: 'rgba(250,247,242,0.7)', marginBottom: 36 }}>Install takes 30 seconds. No sign-up required.</p>
          <button style={{ padding: '18px 32px', background: 'var(--flame)', color: 'var(--paper-000)', border: 'none', borderRadius: 6, fontSize: 16, fontWeight: 700, cursor: 'pointer', boxShadow: '0 3px 0 rgba(0,0,0,0.3)' }}>
            <i className="ph ph-download-simple" style={{ marginRight: 10 }}/>Add to Chrome — free
          </button>

          {/* Zee's signature */}
          <div style={{ marginTop: 56, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 20 }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'var(--flame)', color: 'var(--paper-000)', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-display)', fontSize: 22 }}>Z</div>
            <div style={{ textAlign: 'left' }}>
              <div className="jt-hand" style={{ fontSize: 36, color: 'var(--paper-000)', lineHeight: 1 }}>— Zee</div>
              <div style={{ fontSize: 12, color: 'rgba(250,247,242,0.5)', marginTop: 4 }}>Built this in my garage at 11pm. Hope it saves your week.</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ padding: '56px 48px 32px', background: 'var(--paper-050)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 48 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              <div style={{ width: 28, height: 28, background: 'var(--paper-ink)', display: 'grid', placeItems: 'center', borderRadius: 4 }}>
                <span className="jt-display" style={{ fontSize: 15, color: 'var(--flame)' }}>JT</span>
              </div>
              <span className="jt-display" style={{ fontSize: 18, letterSpacing: '0.05em', color: 'var(--paper-ink)' }}>POWER TOOLS</span>
            </div>
            <p style={{ fontSize: 14, color: 'var(--paper-ink-2)', maxWidth: 340, lineHeight: 1.6 }}>
              Built by contractors, for contractors. Not affiliated with JobTread Software.
            </p>
          </div>
          {[
            ['PRODUCT', ['The tools', 'Pricing', 'Changelog', 'Roadmap']],
            ['LEARN', ['Docs', 'Guides', 'Discord', 'YouTube']],
            ['COMPANY', ['About', 'Privacy', 'Contact', 'Support']],
          ].map(([h, items]) => (
            <div key={h}>
              <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.1em', color: 'var(--paper-ink-3)', marginBottom: 14 }}>{h}</div>
              {items.map(i => <div key={i} style={{ fontSize: 14, color: 'var(--paper-ink-2)', padding: '4px 0', cursor: 'pointer' }}>{i}</div>)}
            </div>
          ))}
        </div>
        <div style={{ marginTop: 48, paddingTop: 20, borderTop: '1px solid var(--paper-rule)', display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--paper-ink-3)' }}>
          <span>© 2026 JT Power Tools · Made in Oklahoma</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}><span className="jt-dot paper-green"/>All systems running</span>
        </div>
      </footer>
    </div>
  );
}

window.LandingFrameV3 = LandingFrameV3;
