/* global React */
// Popup v3 — warmer dark, film grain, Zee's fingerprint in the footer.

function PopupFrameV3() {
  const [tab, setTab] = React.useState('tools');
  return (
    <div className="jt-frame jt-grain-dark" style={{ width: 400, height: 620, display: 'flex', flexDirection: 'column', background: 'var(--ink-050)', overflow: 'hidden', position: 'relative' }}>
      <div className="jt-tape" style={{ height: 6, flexShrink: 0 }}/>

      {/* Header */}
      <div style={{ padding: '16px 18px 14px', background: 'var(--ink-100)', borderBottom: '1px solid var(--rule-soft)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, background: 'var(--flame)', display: 'grid', placeItems: 'center', borderRadius: 4, boxShadow: '0 2px 0 rgba(0,0,0,0.3)' }}>
            <span className="jt-display" style={{ fontSize: 17, color: '#0B0B0B' }}>JT</span>
          </div>
          <div style={{ flex: 1 }}>
            <div className="jt-display" style={{ fontSize: 20, letterSpacing: '0.04em', color: 'var(--ink-900)' }}>POWER TOOLS</div>
            <div style={{ fontSize: 11, color: 'var(--ink-600)', marginTop: 1 }}>
              <span className="jt-dot" style={{ marginRight: 6, verticalAlign: 'middle' }}/>
              Ready — 8 tools running
            </div>
          </div>
          <button style={iconBtnV3} title="Settings"><i className="ph ph-gear-six"/></button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', padding: '0 10px', background: 'var(--ink-050)', borderBottom: '1px solid var(--rule-soft)' }}>
        {[
          { id: 'tools', icon: 'ph-wrench', label: 'Tools' },
          { id: 'theme', icon: 'ph-paint-roller', label: 'Look' },
          { id: 'account', icon: 'ph-id-badge', label: 'You' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            flex: 1, padding: '12px 0', background: 'transparent', border: 'none',
            borderBottom: `2px solid ${tab === t.id ? 'var(--flame)' : 'transparent'}`,
            color: tab === t.id ? 'var(--ink-900)' : 'var(--ink-600)',
            cursor: 'pointer', fontFamily: 'var(--font-ui)', fontSize: 13, fontWeight: 600,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}>
            <i className={`ph ${t.icon}`} style={{ fontSize: 15 }}/>
            {t.label}
          </button>
        ))}
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        {tab === 'tools' && <ToolsTabV3/>}
        {tab === 'theme' && <ThemeTabV3/>}
        {tab === 'account' && <AccountTabV3/>}
      </div>

      {/* Footer — signed by Zee */}
      <div style={{ padding: '10px 18px', borderTop: '1px solid var(--rule)', background: 'var(--ink-000)', display: 'flex', alignItems: 'center', gap: 8, fontSize: 10, color: 'var(--ink-500)' }}>
        <i className="ph ph-wrench" style={{ fontSize: 12, color: 'var(--flame)' }}/>
        <span>v2.3.0</span>
        <span style={{ marginLeft: 'auto' }} className="jt-hand">— Zee</span>
      </div>
    </div>
  );
}

const iconBtnV3 = {
  width: 32, height: 32, background: 'var(--ink-200)',
  border: '1px solid var(--rule)', color: 'var(--ink-700)',
  cursor: 'pointer', borderRadius: 4, fontSize: 15,
  display: 'grid', placeItems: 'center',
};

function ToolsTabV3() {
  return (
    <div>
      <div style={{ margin: 14, padding: 16, background: 'var(--ink-100)', border: '1px solid var(--rule)', borderRadius: 8, display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{ width: 40, height: 40, background: 'var(--flame-soft)', border: '1px solid var(--flame)', borderRadius: 6, display: 'grid', placeItems: 'center', color: 'var(--flame)', fontSize: 20 }}>
          <i className="ph ph-power"/>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink-900)' }}>All tools on</div>
          <div style={{ fontSize: 12, color: 'var(--ink-600)' }}>Turn the whole kit on or off</div>
        </div>
        <ToggleV3 on={true}/>
      </div>

      <BeltV3 title="Schedule" subtitle="Make the calendar actually usable" icon="ph-calendar-check" open={true} items={[
        ['Task checkboxes', 'Check off cards without opening', true],
        ['Hide empty types', 'Collapse columns with nothing in them', true],
        ['Fat Gantt lines', 'Thicker dependency lines', false],
        ['Auto-collapse done', 'Hide 100%-complete groups', false],
      ]}/>
      <BeltV3 title="Writing & copy" subtitle="Rich text, templates, notes" icon="ph-pencil-simple-line" items={[
        ['Rich text formatting', 'Bold, italic, lists anywhere', true],
        ['Message templates', 'Save signatures & replies', true],
        ['Quick notes', 'Notepad on every page · Q+N', false],
      ]}/>
      <BeltV3 title="Money" subtitle="Totals, budgets, bills" icon="ph-calculator" items={[
        ['Live auto-sum', 'Cost/price/profit from selection', true],
        ['Budget changelog', 'See who changed what', false],
      ]}/>

      <div style={{ padding: '14px 18px 22px', borderTop: '1px solid var(--rule-soft)', marginTop: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>23 tools · 8 running</div>
        <a style={{ fontSize: 11, color: 'var(--flame)', fontWeight: 600, cursor: 'pointer' }}>See all →</a>
      </div>
    </div>
  );
}

function BeltV3({ title, subtitle, icon, open, items = [] }) {
  const [o, setO] = React.useState(!!open);
  return (
    <div style={{ margin: '0 14px 10px', background: 'var(--ink-100)', border: '1px solid var(--rule)', borderRadius: 8, overflow: 'hidden' }}>
      <button onClick={() => setO(!o)} style={{
        width: '100%', padding: '12px 14px', background: 'transparent', border: 'none',
        display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', color: 'var(--ink-800)',
      }}>
        <i className={`ph ${icon}`} style={{ fontSize: 18, color: 'var(--flame)' }}/>
        <div style={{ flex: 1, textAlign: 'left' }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink-900)' }}>{title}</div>
          <div style={{ fontSize: 11, color: 'var(--ink-600)' }}>{subtitle}</div>
        </div>
        <i className={`ph ph-caret-${o ? 'up' : 'down'}`} style={{ color: 'var(--ink-500)', fontSize: 12 }}/>
      </button>
      {o && (
        <div style={{ borderTop: '1px solid var(--rule-soft)' }}>
          {items.map((it, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px',
              borderTop: i === 0 ? 'none' : '1px solid var(--rule-soft)',
            }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12.5, color: 'var(--ink-900)', fontWeight: 500 }}>{it[0]}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-600)' }}>{it[1]}</div>
              </div>
              <ToggleV3 on={it[2]}/>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ToggleV3({ on }) {
  return (
    <div style={{
      width: 32, height: 18, borderRadius: 9,
      background: on ? 'var(--flame)' : 'var(--ink-200)',
      border: `1px solid ${on ? 'var(--flame)' : 'var(--rule)'}`,
      position: 'relative', flexShrink: 0,
    }}>
      <div style={{
        position: 'absolute', top: 1, left: on ? 15 : 1,
        width: 14, height: 14, background: '#fff', borderRadius: '50%',
        transition: 'left 0.15s', boxShadow: '0 1px 2px rgba(0,0,0,0.3)',
      }}/>
    </div>
  );
}

function ThemeTabV3() {
  const [color, setColor] = React.useState('#FE4C0D');
  return (
    <div style={{ padding: 16 }}>
      <h3 className="jt-display" style={{ fontSize: 26, color: 'var(--ink-900)', marginBottom: 4 }}>MAKE IT YOURS</h3>
      <p style={{ fontSize: 12, color: 'var(--ink-600)', marginBottom: 18 }}>Repaint JobTread with your brand colors.</p>

      <div style={{ background: 'var(--ink-100)', border: '1px solid var(--rule)', borderRadius: 8, padding: 14, marginBottom: 14 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ink-600)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10 }}>Primary color</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <div style={{ width: 48, height: 48, background: color, borderRadius: 6, border: '1px solid var(--rule)' }}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink-900)' }}>{color}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-600)' }}>Tap a swatch to swap</div>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 6 }}>
          {['#FE4C0D', '#2563EB', '#16A34A', '#7C3AED', '#DB2777', '#0891B2', '#F59E0B', '#64748B', '#DC2626', '#059669', '#D946EF', '#0F172A'].map(c => (
            <button key={c} onClick={() => setColor(c)} style={{
              aspectRatio: '1', background: c, borderRadius: 4,
              border: `2px solid ${c === color ? 'var(--ink-900)' : 'var(--rule)'}`,
              cursor: 'pointer',
            }}/>
          ))}
        </div>
      </div>

      {[
        ['Dark mode', 'Easier on the eyes after 6pm', true],
        ['High contrast', 'Bigger text, stronger borders', false],
        ['Your logo in header', 'Replaces JobTread logo', false],
      ].map(([t, s, on]) => (
        <div key={t} style={{ padding: '12px 0', borderTop: '1px solid var(--rule-soft)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, color: 'var(--ink-900)', fontWeight: 500 }}>{t}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-600)' }}>{s}</div>
          </div>
          <ToggleV3 on={on}/>
        </div>
      ))}
    </div>
  );
}

function AccountTabV3() {
  return (
    <div style={{ padding: 16 }}>
      <div style={{ background: 'var(--ink-100)', border: '1px solid var(--rule)', borderRadius: 8, overflow: 'hidden', marginBottom: 16 }}>
        <div className="jt-tape" style={{ height: 6 }}/>
        <div style={{ padding: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
            <div style={{ width: 48, height: 48, background: 'var(--flame)', borderRadius: '50%', display: 'grid', placeItems: 'center', color: '#0B0B0B', fontFamily: 'var(--font-display)', fontSize: 22 }}>
              Z
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink-900)' }}>Zee</div>
              <div style={{ fontSize: 12, color: 'var(--ink-600)' }}>zee@jtpowertools.com</div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2 }}>Titus Contracting · Owner</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <div style={{ flex: 1, padding: '8px 10px', background: 'var(--flame-soft)', border: '1px solid var(--flame)', borderRadius: 4, textAlign: 'center' }}>
              <div style={{ fontSize: 10, color: 'var(--flame)', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Power user</div>
            </div>
            <div style={{ flex: 1, padding: '8px 10px', background: 'var(--ink-050)', border: '1px solid var(--rule)', borderRadius: 4, textAlign: 'center' }}>
              <div style={{ fontSize: 10, color: 'var(--green)', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                <span className="jt-dot" style={{ verticalAlign: 'middle', marginRight: 4 }}/>Active
              </div>
            </div>
          </div>
        </div>
      </div>

      {[
        ['ph-users-three', 'Your team', '8 of 15 seats used'],
        ['ph-robot', 'AI helper setup', 'Connect Claude or ChatGPT'],
        ['ph-receipt', 'Receipts & billing', 'Renews Dec 14, 2026'],
        ['ph-lifebuoy', 'Support', 'Email, Discord, docs'],
      ].map(([icon, title, sub]) => (
        <a key={title} style={{
          display: 'flex', alignItems: 'center', gap: 14, padding: '14px 12px',
          borderTop: '1px solid var(--rule-soft)', cursor: 'pointer',
        }}>
          <i className={`ph ${icon}`} style={{ color: 'var(--flame)', fontSize: 18 }}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, color: 'var(--ink-900)', fontWeight: 600 }}>{title}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-600)' }}>{sub}</div>
          </div>
          <i className="ph ph-arrow-right" style={{ color: 'var(--ink-500)', fontSize: 14 }}/>
        </a>
      ))}
    </div>
  );
}

window.PopupFrameV3 = PopupFrameV3;
