/* global React */
// The first-visit "Choose your side" modal — the buffet moment.

function ChooseSideModal({ open, onChoose }) {
  if (!open) return null;
  const [hover, setHover] = React.useState(null);

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 100,
      background: 'rgba(12, 10, 8, 0.72)',
      backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)',
      display: 'grid', placeItems: 'center',
      animation: 'jtFadeIn 0.3s ease',
    }}>
      <style>{`
        @keyframes jtFadeIn { from { opacity: 0 } to { opacity: 1 } }
        @keyframes jtLift { from { opacity: 0; transform: translateY(16px) } to { opacity: 1; transform: translateY(0) } }
      `}</style>

      <div style={{
        width: 880, maxWidth: '92vw',
        background: '#faf7f2',
        borderRadius: 16,
        padding: '48px 48px 40px',
        boxShadow: '0 40px 120px rgba(0,0,0,0.5), 0 4px 12px rgba(0,0,0,0.3)',
        position: 'relative', overflow: 'hidden',
        animation: 'jtLift 0.4s cubic-bezier(0.2, 0.9, 0.3, 1) both',
      }}>
        {/* Grain */}
        <div style={{
          position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0.5, mixBlendMode: 'multiply',
          backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 0.35 0 0 0 0 0.28 0 0 0 0 0.18 0 0 0 0.12 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
        }}/>

        {/* Hand-written note taped at top */}
        <div className="jt-hand" style={{
          position: 'absolute', top: -14, left: '50%', transform: 'translateX(-50%) rotate(-1.5deg)',
          padding: '6px 16px', background: '#fde35a', color: '#3a3220',
          fontSize: 16, fontWeight: 600,
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
        }}>
          it's a buffet — take what you want
        </div>

        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ textAlign: 'center', marginBottom: 36 }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#FE4C0D', marginBottom: 10 }}>
              Welcome
            </div>
            <h2 className="jt-display" style={{ fontSize: 72, color: '#1d1a15', lineHeight: 0.9, marginBottom: 14 }}>
              PICK <span style={{ fontFamily: 'Instrument Serif, serif', fontStyle: 'italic', color: '#FE4C0D', fontWeight: 400 }}>your</span> SIDE.
            </h2>
            <p style={{ fontSize: 15, color: '#5a5145', maxWidth: 440, margin: '0 auto', lineHeight: 1.5 }}>
              Some people love white-paper websites. Some live in dark mode. We don't care — pick one. You can flip anytime.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginBottom: 28 }}>
            <SideCard
              side="light"
              title="LIGHT"
              sub="Warm paper. Zee's signed notes. Like a well-thumbed manual."
              hover={hover === 'light'}
              onHover={() => setHover('light')}
              onLeave={() => setHover(null)}
              onClick={() => onChoose('light')}
            />
            <SideCard
              side="dark"
              title="DARK"
              sub="Workshop at 11pm. The lights are off for a reason."
              hover={hover === 'dark'}
              onHover={() => setHover('dark')}
              onLeave={() => setHover(null)}
              onClick={() => onChoose('dark')}
            />
          </div>

          <div style={{ textAlign: 'center', fontSize: 12, color: '#8a8172' }}>
            Pssst — the extension itself stays dark either way. That part's the workshop.
          </div>
        </div>
      </div>
    </div>
  );
}

function SideCard({ side, title, sub, hover, onHover, onLeave, onClick }) {
  const dark = side === 'dark';
  return (
    <button
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      onClick={onClick}
      style={{
        all: 'unset',
        cursor: 'pointer',
        background: dark ? '#151310' : '#f3eee2',
        color: dark ? '#e8e3d7' : '#1d1a15',
        border: `2px solid ${hover ? '#FE4C0D' : (dark ? '#2a2620' : '#d4ccb9')}`,
        borderRadius: 12, padding: 24,
        display: 'flex', flexDirection: 'column', gap: 14,
        position: 'relative', overflow: 'hidden',
        transition: 'transform 0.25s ease, border-color 0.2s ease',
        transform: hover ? 'translateY(-3px)' : 'translateY(0)',
        boxShadow: hover
          ? (dark ? '0 14px 40px rgba(254, 76, 13, 0.3)' : '0 14px 40px rgba(29, 26, 21, 0.2)')
          : '0 2px 6px rgba(0,0,0,0.08)',
      }}
    >
      {/* Mini preview of the aesthetic */}
      <div style={{
        aspectRatio: '16/9',
        background: dark ? '#0d0c0a' : '#faf7f2',
        border: dark ? '1px solid #2a2620' : '1px solid #d4ccb9',
        borderRadius: 6, padding: 14, display: 'flex', flexDirection: 'column', gap: 6,
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Mini grain */}
        <div style={{
          position: 'absolute', inset: 0, pointerEvents: 'none',
          opacity: dark ? 0.4 : 0.5, mixBlendMode: dark ? 'overlay' : 'multiply',
          backgroundImage: dark
            ? "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 120 120' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='1.2' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 1 0 0 0 0 0.92 0 0 0 0 0.82 0 0 0 0.14 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")"
            : "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 120 120' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='1.2' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 0.35 0 0 0 0 0.28 0 0 0 0 0.18 0 0 0 0.12 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
        }}/>
        <div style={{ display: 'flex', gap: 4, position: 'relative' }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#FF5F57' }}/>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#FDBC2C' }}/>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#28C940' }}/>
        </div>
        <div className="jt-display" style={{ fontSize: 22, letterSpacing: '0.02em', position: 'relative', color: dark ? '#e8e3d7' : '#1d1a15', marginTop: 4 }}>
          23 HACKS
        </div>
        <div style={{ fontFamily: 'Instrument Serif, serif', fontStyle: 'italic', fontSize: 20, color: '#FE4C0D', position: 'relative', lineHeight: 0.9 }}>
          awesome.
        </div>
        <div style={{ fontSize: 9, color: dark ? '#7a7060' : '#8a8172', position: 'relative', marginTop: 'auto' }}>
          ● ● ●
        </div>
      </div>

      <div>
        <div className="jt-display" style={{ fontSize: 32, letterSpacing: '0.04em', marginBottom: 4, color: hover ? '#FE4C0D' : 'inherit', transition: 'color 0.2s' }}>
          {title}
        </div>
        <div style={{ fontSize: 13, color: dark ? '#a89f8b' : '#5a5145', lineHeight: 1.5 }}>{sub}</div>
      </div>

      <div style={{
        marginTop: 2,
        fontSize: 12, fontWeight: 700, color: '#FE4C0D',
        display: 'flex', alignItems: 'center', gap: 6,
        opacity: hover ? 1 : 0.7, transition: 'opacity 0.2s',
      }}>
        Pick this side <i className="ph ph-arrow-right"/>
      </div>
    </button>
  );
}

window.ChooseSideModal = ChooseSideModal;
