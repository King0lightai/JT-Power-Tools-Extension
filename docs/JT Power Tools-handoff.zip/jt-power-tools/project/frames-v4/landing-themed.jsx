/* global React */
// Landing v4 — theme-aware. Uses --t-* vars so the same component works in light + dark.

function LandingFrameV4() {
  return (
    <div className="jt-frame-t jt-grain-t" style={{ width: 1280, minHeight: 3800, overflow: 'hidden', position: 'relative' }}>
      <div className="jt-tape-t" style={{ height: 8 }}/>

      {/* Nav */}
      <nav style={{ display: 'flex', alignItems: 'center', padding: '18px 48px', borderBottom: '1px solid var(--t-rule)', background: 'var(--t-bg)', position: 'relative', zIndex: 5 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, background: 'var(--t-logo-bg)', display: 'grid', placeItems: 'center', borderRadius: 4 }}>
            <span className="jt-display" style={{ fontSize: 17, color: 'var(--t-logo-fg)' }}>JT</span>
          </div>
          <span className="jt-display" style={{ fontSize: 18, letterSpacing: '0.05em', color: 'var(--t-ink)' }}>POWER TOOLS</span>
        </div>
        <div style={{ display: 'flex', gap: 28, marginLeft: 64 }}>
          {['The tools', 'Pricing', 'Roadmap', 'About', 'Docs'].map(l => (
            <a key={l} style={{ fontSize: 14, color: 'var(--t-ink-2)', cursor: 'pointer', fontWeight: 500 }}>{l}</a>
          ))}
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 10, alignItems: 'center' }}>
          <ThemeSwitchChip/>
          <button style={{ padding: '10px 16px', background: 'transparent', border: '1px solid var(--t-rule)', color: 'var(--t-ink)', fontSize: 13, cursor: 'pointer', fontWeight: 600, borderRadius: 5 }}>Sign in</button>
          <button style={{ padding: '10px 18px', background: 'var(--t-btn-ink)', border: 'none', color: 'var(--t-btn-ink-fg)', fontSize: 13, cursor: 'pointer', fontWeight: 700, borderRadius: 5 }}>Install free →</button>
        </div>
      </nav>

      {/* HERO */}
      <section style={{ padding: '90px 48px 40px', borderBottom: '1px solid var(--t-rule)', position: 'relative' }}>
        <div style={{ position: 'absolute', top: 140, right: 72, transform: 'rotate(-6deg)', width: 180, textAlign: 'center' }}>
          <div className="jt-hand" style={{ color: 'var(--t-ink-pen)', fontSize: 28, lineHeight: 1.1, marginBottom: 6 }}>
            the one feature<br/>JobTread won't ship
          </div>
          <svg width="60" height="40" viewBox="0 0 60 40" style={{ margin: '0 auto', transform: 'rotate(20deg)' }}>
            <path d="M5,5 Q20,25 50,30" stroke="var(--t-ink-pen)" strokeWidth="2" fill="none" strokeLinecap="round"/>
            <path d="M45,25 L50,30 L44,34" stroke="var(--t-ink-pen)" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 0.9fr', gap: 56, alignItems: 'end' }}>
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px', background: 'var(--t-flame-wash)', border: '1px solid var(--t-flame-ink)', borderRadius: 20, marginBottom: 28 }}>
              <i className="ph ph-hammer" style={{ color: 'var(--t-flame-ink)', fontSize: 14 }}/>
              <span style={{ fontSize: 12, color: 'var(--t-flame-ink)', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Built by a contractor, for contractors</span>
            </div>
            <h1 className="jt-display" style={{ fontSize: 168, color: 'var(--t-ink)', lineHeight: 0.86, marginBottom: 28 }}>
              23 HACKS<br/>
              THAT MAKE<br/>
              JOBTREAD<br/>
              <span className="jt-serif" style={{ fontSize: 180, fontStyle: 'italic', color: 'var(--t-flame)' }}>awesome.</span>
            </h1>
          </div>
          <div style={{ paddingBottom: 32 }}>
            <p style={{ fontSize: 20, color: 'var(--t-ink-2)', lineHeight: 1.55, marginBottom: 28, maxWidth: 400 }}>
              Task checkboxes. Rich text. Dark mode. An AI helper that reads your jobs. And all the other little things you've wished JobTread had. <strong style={{ color: 'var(--t-ink)' }}>One Chrome extension.</strong>
            </p>
            <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
              <button style={{ padding: '16px 24px', background: 'var(--t-flame)', color: '#0B0B0B', border: 'none', borderRadius: 6, fontSize: 14, fontWeight: 700, cursor: 'pointer', boxShadow: '0 3px 0 rgba(0, 0, 0, 0.2)' }}>
                <i className="ph ph-download-simple" style={{ marginRight: 8 }}/>Install free
              </button>
              <button style={{ padding: '16px 24px', background: 'transparent', color: 'var(--t-ink)', border: '1px solid var(--t-rule)', borderRadius: 6, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
                Watch 90-sec demo
              </button>
            </div>
            <div style={{ display: 'flex', gap: 18, flexWrap: 'wrap' }}>
              <span style={{ fontSize: 12, color: 'var(--t-ink-3)' }}>● Free forever plan</span>
              <span style={{ fontSize: 12, color: 'var(--t-ink-3)' }}>● No credit card</span>
              <span style={{ fontSize: 12, color: 'var(--t-ink-3)' }}>● 2,400+ contractors</span>
            </div>
          </div>
        </div>

        {/* Screenshot frame */}
        <div style={{ marginTop: 64, background: 'var(--t-ink)', padding: 14, borderRadius: 4, boxShadow: 'var(--t-shadow-lift)' }}>
          <div style={{ display: 'flex', gap: 6, padding: '6px 4px 10px', alignItems: 'center' }}>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#FF5F57' }}/>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#FDBC2C' }}/>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#28C940' }}/>
            <span style={{ marginLeft: 12, fontSize: 12, color: 'var(--t-ink-4)' }}>app.jobtread.com/schedule — with Power Tools on</span>
          </div>
          <div style={{ aspectRatio: '16/9', background: 'var(--t-bg-4)', borderRadius: 2, display: 'grid', placeItems: 'center', textAlign: 'center' }}>
            <div>
              <i className="ph ph-image" style={{ fontSize: 44, color: 'var(--t-ink-4)', marginBottom: 12 }}/>
              <div style={{ fontSize: 14, color: 'var(--t-ink-3)' }}>Screenshot of JobTread schedule with checkboxes enabled</div>
              <div style={{ fontSize: 12, color: 'var(--t-ink-4)', marginTop: 4 }}>(Real product shot goes here)</div>
            </div>
          </div>
        </div>
      </section>

      {/* BEFORE/AFTER */}
      <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--t-rule)' }}>
        <div style={{ textAlign: 'center', marginBottom: 48 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--t-flame-ink)', marginBottom: 12 }}>The receipts</div>
          <h2 className="jt-display" style={{ fontSize: 84, color: 'var(--t-ink)' }}>
            JOBTREAD <span className="jt-serif" style={{ fontStyle: 'italic', color: 'var(--t-ink-3)' }}>without</span> <span style={{ color: 'var(--t-ink-4)' }}>vs.</span> <span style={{ color: 'var(--t-flame)' }}>with.</span>
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          {[
            { label: 'WITHOUT', sub: 'Stock JobTread', tone: 'muted', items: [
              'Open card. Scroll. Find task. Open task. Check. Back. Next.',
              'Plain text everywhere. No bold, no bullets.',
              'White UI only. Your eyes at 8pm.',
              'Ask Claude anything? Copy-paste into another tab.',
            ]},
            { label: 'WITH POWER TOOLS', sub: '30 seconds to install', tone: 'flame', items: [
              'Click the box on the card. Done.',
              'Rich text. Lists. Colors. Everywhere.',
              'Real dark mode. Eye-friendly after dark.',
              'Claude reads your jobs live. Ask in plain English.',
            ]},
          ].map(col => (
            <div key={col.label} style={{
              background: col.tone === 'flame' ? 'var(--t-flame-wash)' : 'var(--t-bg-3)',
              border: `1px solid ${col.tone === 'flame' ? 'var(--t-flame)' : 'var(--t-rule)'}`,
              borderRadius: 12, padding: 36,
            }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '0.12em', color: col.tone === 'flame' ? 'var(--t-flame-ink)' : 'var(--t-ink-3)', marginBottom: 4 }}>{col.label}</div>
              <div style={{ fontSize: 13, color: 'var(--t-ink-2)', marginBottom: 24 }}>{col.sub}</div>
              {col.items.map((t, i) => (
                <div key={i} style={{ display: 'flex', gap: 12, padding: '14px 0', borderTop: i === 0 ? 'none' : '1px solid var(--t-rule-soft)', alignItems: 'flex-start' }}>
                  <i className={`ph ${col.tone === 'flame' ? 'ph-check-circle' : 'ph-x-circle'}`} style={{ color: col.tone === 'flame' ? 'var(--t-flame)' : 'var(--t-ink-4)', fontSize: 20, flexShrink: 0, marginTop: 2 }}/>
                  <span style={{ fontSize: 16, color: col.tone === 'flame' ? 'var(--t-ink)' : 'var(--t-ink-2)', lineHeight: 1.5 }}>{t}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* TOOLBOX */}
      <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--t-rule)' }}>
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--t-flame-ink)', marginBottom: 12 }}>The Toolbox</div>
          <h2 className="jt-display" style={{ fontSize: 84, color: 'var(--t-ink)' }}>EVERY HACK <span style={{ color: 'var(--t-flame)' }}>YOU'VE WANTED.</span></h2>
          <p style={{ fontSize: 17, color: 'var(--t-ink-2)', maxWidth: 600, margin: '18px auto 0' }}>Each one fixes something you've cursed out loud.</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18 }}>
          {[
            ['ph-check-square', 'Task checkboxes', 'Check off schedule cards without opening them. Save 3 clicks per task.', 'Most loved'],
            ['ph-text-aa', 'Rich text everywhere', 'Bold, italic, lists, colors in every description box.'],
            ['ph-moon', 'Real dark mode', 'Actually readable. Not an afterthought tint.'],
            ['ph-robot', 'AI helper', 'Ask Claude about your jobs. Get answers from your data.', 'New'],
            ['ph-note-pencil', 'Quick notes', 'Persistent notepad on any page. Q+N opens it.'],
            ['ph-clipboard-text', 'Message templates', 'Save signatures and common replies. Paste in one click.'],
            ['ph-calculator', 'Auto-sum totals', 'Highlight rows — see cost, price, profit live.'],
            ['ph-file-pdf', 'PDF markup tools', 'Stamps, eraser, and annotations on PDFs.'],
            ['ph-columns', 'Frozen tabs', 'Keep job tabs visible while scrolling long pages.'],
          ].map(([i, t, d, tag]) => (
            <div key={t} style={{
              background: 'var(--t-bg-2)', border: '1px solid var(--t-rule)', borderRadius: 10,
              padding: 28, position: 'relative',
            }}>
              {tag && (
                <div style={{
                  position: 'absolute', top: 14, right: 14,
                  fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase',
                  padding: '4px 8px', borderRadius: 10,
                  background: 'var(--t-flame)', color: '#0B0B0B',
                }}>{tag}</div>
              )}
              <div style={{
                width: 56, height: 56, borderRadius: 10, background: 'var(--t-bg-3)',
                border: '1px solid var(--t-rule)',
                display: 'grid', placeItems: 'center', color: 'var(--t-flame-ink)', marginBottom: 18,
              }}>
                <i className={`ph ${i}`} style={{ fontSize: 28 }}/>
              </div>
              <h3 style={{ fontSize: 20, fontWeight: 700, color: 'var(--t-ink)', marginBottom: 6, letterSpacing: '-0.01em' }}>{t}</h3>
              <p style={{ fontSize: 14, color: 'var(--t-ink-2)', lineHeight: 1.55 }}>{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIAL */}
      <section style={{ padding: '96px 48px', borderBottom: '1px solid var(--t-rule)' }}>
        <div style={{ maxWidth: 960, margin: '0 auto', textAlign: 'center' }}>
          <i className="ph ph-quotes" style={{ fontSize: 40, color: 'var(--t-flame)', marginBottom: 20 }}/>
          <p className="jt-serif" style={{ fontSize: 52, color: 'var(--t-ink)', lineHeight: 1.15, fontStyle: 'italic' }}>
            "I get three hours back a week. The task checkboxes alone paid for the whole year."
          </p>
          <div style={{ marginTop: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14 }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'var(--t-bg-3)', border: '1px solid var(--t-rule)' }}/>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--t-ink)' }}>David B.</div>
              <div style={{ fontSize: 13, color: 'var(--t-ink-3)' }}>Operations Lead · Tulsa, OK</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: '96px 48px', background: 'var(--t-ink)', color: 'var(--t-bg)', borderBottom: '1px solid var(--t-rule)' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', textAlign: 'center' }}>
          <h2 className="jt-display" style={{ fontSize: 96, marginBottom: 20, lineHeight: 0.9, color: 'var(--t-bg)' }}>
            STOP FIGHTING JOBTREAD.<br/>
            <span className="jt-serif" style={{ fontStyle: 'italic', color: 'var(--t-flame)', fontSize: 104 }}>Start using it.</span>
          </h2>
          <p style={{ fontSize: 18, color: 'var(--t-bg-4)', marginBottom: 36 }}>Install takes 30 seconds. No sign-up required.</p>
          <button style={{ padding: '18px 32px', background: 'var(--t-flame)', color: '#0B0B0B', border: 'none', borderRadius: 6, fontSize: 16, fontWeight: 700, cursor: 'pointer' }}>
            <i className="ph ph-download-simple" style={{ marginRight: 10 }}/>Add to Chrome — free
          </button>
          <div style={{ marginTop: 56, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 20 }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'var(--t-flame)', color: '#0B0B0B', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-display)', fontSize: 22 }}>Z</div>
            <div style={{ textAlign: 'left' }}>
              <div className="jt-hand" style={{ fontSize: 36, color: 'var(--t-bg)', lineHeight: 1 }}>— Zee</div>
              <div style={{ fontSize: 12, color: 'var(--t-bg-4)', marginTop: 4 }}>Built this in my garage at 11pm. Hope it saves your week.</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ padding: '56px 48px 32px', background: 'var(--t-bg-2)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 48 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              <div style={{ width: 28, height: 28, background: 'var(--t-logo-bg)', display: 'grid', placeItems: 'center', borderRadius: 4 }}>
                <span className="jt-display" style={{ fontSize: 15, color: 'var(--t-logo-fg)' }}>JT</span>
              </div>
              <span className="jt-display" style={{ fontSize: 18, letterSpacing: '0.05em', color: 'var(--t-ink)' }}>POWER TOOLS</span>
            </div>
            <p style={{ fontSize: 14, color: 'var(--t-ink-2)', maxWidth: 340, lineHeight: 1.6 }}>
              Built by contractors, for contractors. Not affiliated with JobTread Software.
            </p>
          </div>
          {[
            ['PRODUCT', ['The tools', 'Pricing', 'Changelog', 'Roadmap']],
            ['LEARN', ['Docs', 'Guides', 'Discord', 'YouTube']],
            ['COMPANY', ['About', 'Privacy', 'Contact', 'Support']],
          ].map(([h, items]) => (
            <div key={h}>
              <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.1em', color: 'var(--t-ink-3)', marginBottom: 14 }}>{h}</div>
              {items.map(i => <div key={i} style={{ fontSize: 14, color: 'var(--t-ink-2)', padding: '4px 0', cursor: 'pointer' }}>{i}</div>)}
            </div>
          ))}
        </div>
      </footer>
    </div>
  );
}

// Little chip that toggles theme via a host callback on the window
function ThemeSwitchChip() {
  const [theme, setTheme] = React.useState(() => window.__jtTheme || 'light');
  React.useEffect(() => {
    const handler = (e) => setTheme(e.detail.theme);
    window.addEventListener('jt-theme-change', handler);
    return () => window.removeEventListener('jt-theme-change', handler);
  }, []);
  const flip = () => {
    const next = theme === 'light' ? 'dark' : 'light';
    window.__jtSetTheme?.(next);
  };
  return (
    <button onClick={flip} style={{
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '8px 12px', background: 'var(--t-bg-3)',
      border: '1px solid var(--t-rule)', color: 'var(--t-ink-2)',
      fontSize: 12, fontWeight: 600, borderRadius: 20, cursor: 'pointer',
    }}>
      <i className={`ph ${theme === 'light' ? 'ph-sun' : 'ph-moon'}`} style={{ color: 'var(--t-flame)', fontSize: 14 }}/>
      Flip sides
    </button>
  );
}

window.LandingFrameV4 = LandingFrameV4;
